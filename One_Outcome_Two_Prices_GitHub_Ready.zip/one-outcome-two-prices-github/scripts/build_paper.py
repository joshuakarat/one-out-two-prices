#!/usr/bin/env python3
"""Build and style the publication PDF and editable DOCX research paper."""

from __future__ import annotations

import json
import os
import re
import subprocess
from pathlib import Path

from docx import Document
from docx.enum.section import WD_ORIENT
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import (
    WD_ALIGN_PARAGRAPH,
    WD_BREAK,
    WD_LINE_SPACING,
    WD_TAB_ALIGNMENT,
)
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor, Twips


ROOT = Path(__file__).resolve().parents[1]
PAPER = ROOT / "paper"
BUILD = PAPER / "build"
OUTPUT = PAPER / "output"
SOURCE = PAPER / "paper.md"
BIBLIOGRAPHY = PAPER / "references.bib"
REFERENCE_DOCX = BUILD / "reference.docx"
DOCX_OUTPUT = OUTPUT / "Joshua_Karat_One_Outcome_Two_Prices.docx"
PDF_OUTPUT = OUTPUT / "Joshua_Karat_One_Outcome_Two_Prices.pdf"

CONTENT_WIDTH_DXA = 9360
TABLE_INDENT_DXA = 120
NAVY = "172A46"
BLUE = "2E74B5"
DARK_BLUE = "1F4D78"
TEAL = "2A9D8F"
GREY = "6B7280"
LIGHT_GREY = "D8DEE8"
CALLOUT = "F4F6F9"


def run(command: list[str], cwd: Path | None = None) -> None:
    completed = subprocess.run(
        command,
        cwd=cwd,
        check=False,
        text=True,
        capture_output=True,
    )
    if completed.returncode:
        raise RuntimeError(
            f"Command failed ({completed.returncode}): {' '.join(command)}\n"
            f"{completed.stdout}\n{completed.stderr}"
        )


def set_style_font(
    style,
    name: str,
    size: float,
    color: str = "000000",
    bold: bool | None = None,
    italic: bool | None = None,
) -> None:
    style.font.name = name
    style.font.size = Pt(size)
    style.font.color.rgb = RGBColor.from_string(color)
    if bold is not None:
        style.font.bold = bold
    if italic is not None:
        style.font.italic = italic
    rpr = style.element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.insert(0, rfonts)
    for key in ("ascii", "hAnsi", "eastAsia", "cs"):
        rfonts.set(qn(f"w:{key}"), name)


def set_style_spacing(
    style,
    *,
    before: float,
    after: float,
    line: float,
    alignment: WD_ALIGN_PARAGRAPH | None = None,
) -> None:
    fmt = style.paragraph_format
    fmt.space_before = Pt(before)
    fmt.space_after = Pt(after)
    fmt.line_spacing = line
    if alignment is not None:
        fmt.alignment = alignment


def get_or_add_style(doc: Document, name: str, style_type=WD_STYLE_TYPE.PARAGRAPH):
    for style in doc.styles:
        if style.name == name:
            return style
    try:
        return doc.styles[name]
    except KeyError:
        return doc.styles.add_style(name, style_type)


def set_page_geometry(doc: Document) -> None:
    for section in doc.sections:
        section.orientation = WD_ORIENT.PORTRAIT
        section.page_width = Inches(8.5)
        section.page_height = Inches(11)
        section.top_margin = Inches(1)
        section.right_margin = Inches(1)
        section.bottom_margin = Inches(1)
        section.left_margin = Inches(1)
        section.header_distance = Inches(0.492)
        section.footer_distance = Inches(0.492)


def configure_reference_styles(doc: Document) -> None:
    normal = doc.styles["Normal"]
    set_style_font(normal, "Calibri", 11)
    set_style_spacing(
        normal,
        before=0,
        after=8,
        line=1.333,
        alignment=WD_ALIGN_PARAGRAPH.JUSTIFY,
    )

    for style_name in ("Body Text", "First Paragraph"):
        style = get_or_add_style(doc, style_name)
        set_style_font(style, "Calibri", 11)
        set_style_spacing(
            style,
            before=0,
            after=8,
            line=1.333,
            alignment=WD_ALIGN_PARAGRAPH.JUSTIFY,
        )

    title = doc.styles["Title"]
    set_style_font(title, "Calibri", 30, NAVY, bold=True)
    set_style_spacing(
        title,
        before=190,
        after=8,
        line=1.0,
        alignment=WD_ALIGN_PARAGRAPH.CENTER,
    )

    subtitle = get_or_add_style(doc, "Subtitle")
    set_style_font(subtitle, "Calibri", 15, DARK_BLUE)
    set_style_spacing(
        subtitle,
        before=0,
        after=24,
        line=1.1,
        alignment=WD_ALIGN_PARAGRAPH.CENTER,
    )

    author = get_or_add_style(doc, "Author")
    set_style_font(author, "Calibri", 12, NAVY, bold=True)
    set_style_spacing(
        author,
        before=0,
        after=3,
        line=1.0,
        alignment=WD_ALIGN_PARAGRAPH.CENTER,
    )

    date = get_or_add_style(doc, "Date")
    set_style_font(date, "Calibri", 10.5, GREY)
    set_style_spacing(
        date,
        before=0,
        after=16,
        line=1.0,
        alignment=WD_ALIGN_PARAGRAPH.CENTER,
    )

    heading_specs = {
        "Heading 1": (16, BLUE, 18, 10),
        "Heading 2": (13, BLUE, 12, 6),
        "Heading 3": (12, DARK_BLUE, 8, 4),
    }
    for name, (size, color, before, after) in heading_specs.items():
        style = get_or_add_style(doc, name)
        set_style_font(style, "Calibri", size, color, bold=True)
        set_style_spacing(style, before=before, after=after, line=1.0)
        style.paragraph_format.keep_with_next = True
        style.paragraph_format.keep_together = True

    for name in ("List Bullet", "List Number"):
        style = get_or_add_style(doc, name)
        set_style_font(style, "Calibri", 11)
        set_style_spacing(style, before=0, after=4, line=1.208)
        style.paragraph_format.left_indent = Inches(0.375)
        style.paragraph_format.first_line_indent = Inches(-0.194)

    block = get_or_add_style(doc, "Block Text")
    set_style_font(block, "Calibri", 10.5, NAVY)
    set_style_spacing(
        block,
        before=6,
        after=8,
        line=1.208,
        alignment=WD_ALIGN_PARAGRAPH.LEFT,
    )
    block.paragraph_format.left_indent = Inches(0.28)
    block.paragraph_format.right_indent = Inches(0.18)

    caption = get_or_add_style(doc, "Caption")
    set_style_font(caption, "Calibri", 9.2, NAVY, italic=True)
    set_style_spacing(
        caption,
        before=4,
        after=8,
        line=1.10,
        alignment=WD_ALIGN_PARAGRAPH.CENTER,
    )
    image_caption = get_or_add_style(doc, "Image Caption")
    image_caption.base_style = caption

    table_caption = get_or_add_style(doc, "Table Caption")
    table_caption.base_style = caption
    set_style_font(table_caption, "Calibri", 9.2, NAVY, italic=True)
    set_style_spacing(
        table_caption,
        before=4,
        after=8,
        line=1.10,
        alignment=WD_ALIGN_PARAGRAPH.CENTER,
    )
    table_caption.paragraph_format.keep_with_next = True
    table_caption.paragraph_format.keep_together = True

    bibliography = get_or_add_style(doc, "Bibliography")
    set_style_font(bibliography, "Calibri", 8.75)
    set_style_spacing(
        bibliography,
        before=0,
        after=2.5,
        line=1.04,
        alignment=WD_ALIGN_PARAGRAPH.LEFT,
    )
    bibliography.paragraph_format.left_indent = Inches(0.30)
    bibliography.paragraph_format.first_line_indent = Inches(-0.30)

    table_citation = get_or_add_style(doc, "Table Citation")
    set_style_font(table_citation, "Calibri", 9.5, NAVY, bold=True)
    set_style_spacing(
        table_citation,
        before=4,
        after=4,
        line=1.0,
        alignment=WD_ALIGN_PARAGRAPH.LEFT,
    )
    table_citation.paragraph_format.keep_with_next = True

    code = get_or_add_style(doc, "Source Code")
    set_style_font(code, "Consolas", 8.8, "30343B")
    set_style_spacing(code, before=3, after=5, line=1.0)


def patch_numbering(doc: Document) -> None:
    """Align real numbering definitions to the narrative-proposal list tokens."""

    numbering = doc.part.numbering_part.element
    for level in numbering.findall(".//" + qn("w:lvl")):
        if level.get(qn("w:ilvl")) != "0":
            continue
        ppr = level.find(qn("w:pPr"))
        if ppr is None:
            ppr = OxmlElement("w:pPr")
            level.append(ppr)
        tabs = ppr.find(qn("w:tabs"))
        if tabs is None:
            tabs = OxmlElement("w:tabs")
            ppr.append(tabs)
        for old in list(tabs):
            tabs.remove(old)
        tab = OxmlElement("w:tab")
        tab.set(qn("w:val"), "num")
        tab.set(qn("w:pos"), "720")
        tabs.append(tab)
        ind = ppr.find(qn("w:ind"))
        if ind is None:
            ind = OxmlElement("w:ind")
            ppr.append(ind)
        ind.set(qn("w:left"), "720")
        ind.set(qn("w:hanging"), "360")
        spacing = ppr.find(qn("w:spacing"))
        if spacing is None:
            spacing = OxmlElement("w:spacing")
            ppr.append(spacing)
        spacing.set(qn("w:after"), "80")
        spacing.set(qn("w:line"), "290")
        spacing.set(qn("w:lineRule"), "auto")


def create_reference_docx() -> None:
    BUILD.mkdir(parents=True, exist_ok=True)
    raw = subprocess.run(
        ["pandoc", "--print-default-data-file", "reference.docx"],
        check=True,
        capture_output=True,
    ).stdout
    REFERENCE_DOCX.write_bytes(raw)
    doc = Document(REFERENCE_DOCX)
    set_page_geometry(doc)
    configure_reference_styles(doc)
    patch_numbering(doc)
    doc.core_properties.author = "Joshua Karat"
    doc.core_properties.title = (
        "One Outcome, Two Prices? Rule-Verified No-Arbitrage and Price Discovery "
        "in Event-Contract Probability Surfaces"
    )
    doc.core_properties.subject = "Independent quantitative research paper"
    doc.core_properties.keywords = (
        "prediction markets, no-arbitrage, price discovery, market microstructure"
    )
    doc.save(REFERENCE_DOCX)


def add_bottom_border(paragraph, color: str, size: int = 5) -> None:
    ppr = paragraph._p.get_or_add_pPr()
    pbdr = ppr.find(qn("w:pBdr"))
    if pbdr is None:
        pbdr = OxmlElement("w:pBdr")
        ppr.append(pbdr)
    bottom = pbdr.find(qn("w:bottom"))
    if bottom is None:
        bottom = OxmlElement("w:bottom")
        pbdr.append(bottom)
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), str(size))
    bottom.set(qn("w:space"), "4")
    bottom.set(qn("w:color"), color)


def add_callout_treatment(paragraph) -> None:
    ppr = paragraph._p.get_or_add_pPr()
    shade = ppr.find(qn("w:shd"))
    if shade is None:
        shade = OxmlElement("w:shd")
        ppr.append(shade)
    shade.set(qn("w:val"), "clear")
    shade.set(qn("w:color"), "auto")
    shade.set(qn("w:fill"), CALLOUT)
    pbdr = ppr.find(qn("w:pBdr"))
    if pbdr is None:
        pbdr = OxmlElement("w:pBdr")
        ppr.append(pbdr)
    left = pbdr.find(qn("w:left"))
    if left is None:
        left = OxmlElement("w:left")
        pbdr.append(left)
    left.set(qn("w:val"), "single")
    left.set(qn("w:sz"), "14")
    left.set(qn("w:space"), "7")
    left.set(qn("w:color"), TEAL)


def clear_container(container) -> None:
    for paragraph in container.paragraphs:
        for run in paragraph.runs:
            run._element.getparent().remove(run._element)
    for table in list(container.tables):
        table._element.getparent().remove(table._element)


def append_page_field(paragraph) -> None:
    run = paragraph.add_run()
    begin = OxmlElement("w:fldChar")
    begin.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = " PAGE "
    separate = OxmlElement("w:fldChar")
    separate.set(qn("w:fldCharType"), "separate")
    text = OxmlElement("w:t")
    text.text = "1"
    end = OxmlElement("w:fldChar")
    end.set(qn("w:fldCharType"), "end")
    for element in (begin, instr, separate, text, end):
        run._r.append(element)
    run.font.name = "Calibri"
    run.font.size = Pt(8.5)
    run.font.color.rgb = RGBColor.from_string(GREY)


def configure_headers_and_footers(doc: Document) -> None:
    for section in doc.sections:
        section.different_first_page_header_footer = True
        clear_container(section.first_page_header)
        clear_container(section.first_page_footer)

        clear_container(section.header)
        hp = section.header.paragraphs[0]
        hp.alignment = WD_ALIGN_PARAGRAPH.LEFT
        hp.paragraph_format.space_before = Pt(0)
        hp.paragraph_format.space_after = Pt(0)
        hp.paragraph_format.tab_stops.add_tab_stop(
            Inches(6.5), WD_TAB_ALIGNMENT.RIGHT
        )
        left = hp.add_run("ONE OUTCOME, TWO PRICES?")
        left.bold = True
        right = hp.add_run("\tJOSHUA KARAT")
        for run in (left, right):
            run.font.name = "Calibri"
            run.font.size = Pt(8.5)
            run.font.color.rgb = RGBColor.from_string(GREY)
        add_bottom_border(hp, LIGHT_GREY, 4)

        clear_container(section.footer)
        fp = section.footer.paragraphs[0]
        fp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        fp.paragraph_format.space_before = Pt(0)
        fp.paragraph_format.space_after = Pt(0)
        append_page_field(fp)


def set_cell_margins(cell) -> None:
    tc = cell._tc
    tcpr = tc.get_or_add_tcPr()
    tcmar = tcpr.find(qn("w:tcMar"))
    if tcmar is None:
        tcmar = OxmlElement("w:tcMar")
        tcpr.append(tcmar)
    for side, value in (
        ("top", 80),
        ("bottom", 80),
        ("start", 120),
        ("end", 120),
    ):
        node = tcmar.find(qn(f"w:{side}"))
        if node is None:
            node = OxmlElement(f"w:{side}")
            tcmar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_cell_shading(cell, fill: str) -> None:
    tcpr = cell._tc.get_or_add_tcPr()
    shade = tcpr.find(qn("w:shd"))
    if shade is None:
        shade = OxmlElement("w:shd")
        tcpr.append(shade)
    shade.set(qn("w:val"), "clear")
    shade.set(qn("w:color"), "auto")
    shade.set(qn("w:fill"), fill)


def set_table_borders(table) -> None:
    tblpr = table._tbl.tblPr
    borders = tblpr.find(qn("w:tblBorders"))
    if borders is None:
        borders = OxmlElement("w:tblBorders")
        tblpr.append(borders)
    for side in ("top", "left", "bottom", "right", "insideH", "insideV"):
        edge = borders.find(qn(f"w:{side}"))
        if edge is None:
            edge = OxmlElement(f"w:{side}")
            borders.append(edge)
        edge.set(qn("w:val"), "single")
        edge.set(qn("w:sz"), "4")
        edge.set(qn("w:space"), "0")
        edge.set(qn("w:color"), LIGHT_GREY)


def width_pattern(table) -> list[int]:
    header = [cell.text.strip() for cell in table.rows[0].cells]
    first = header[0] if header else ""
    patterns = {
        "Stage": [1900, 1000, 6460],
        "Sample": [1700, 1100, 1100, 1100, 1680, 1680],
        "Screen": [2300, 1200, 900, 1100, 1300, 2560],
        "Next-minute outcome": [2600, 1800, 1000, 2000, 1960],
        "Specification": (
            [2500, 1000, 1200, 1300, 1800, 1560]
            if len(header) == 6
            else [3360, 1500, 1000, 1750, 1750]
        ),
        "Minutes to settlement": [2160, 2400, 2400, 2400],
        "Horizon": [1000, 1800, 1600, 3100, 1860],
        "Layer": [1100, 3060, 5200],
    }
    if first in patterns and len(patterns[first]) == len(header):
        return patterns[first]
    if len(header) == 5 and first == "Specification":
        return [3360, 1500, 1500, 1500, 1500]
    weights = []
    for index in range(len(header)):
        maximum = max(
            len(row.cells[index].text.strip()) for row in table.rows
        )
        weight = max(10, min(42, maximum))
        if index == 0:
            weight *= 1.35
        weights.append(weight)
    total = sum(weights)
    widths = [max(760, round(CONTENT_WIDTH_DXA * value / total)) for value in weights]
    scale = CONTENT_WIDTH_DXA / sum(widths)
    widths = [round(value * scale) for value in widths]
    widths[-1] += CONTENT_WIDTH_DXA - sum(widths)
    return widths


def set_repeat_table_header(row) -> None:
    trpr = row._tr.get_or_add_trPr()
    header = OxmlElement("w:tblHeader")
    header.set(qn("w:val"), "true")
    trpr.append(header)


def prevent_row_split(row) -> None:
    trpr = row._tr.get_or_add_trPr()
    cant_split = OxmlElement("w:cantSplit")
    cant_split.set(qn("w:val"), "true")
    trpr.append(cant_split)


def format_table(table) -> None:
    widths = width_pattern(table)
    table.autofit = False
    table.alignment = None
    tblpr = table._tbl.tblPr

    tblw = tblpr.find(qn("w:tblW"))
    if tblw is None:
        tblw = OxmlElement("w:tblW")
        tblpr.append(tblw)
    tblw.set(qn("w:w"), str(CONTENT_WIDTH_DXA))
    tblw.set(qn("w:type"), "dxa")

    tblind = tblpr.find(qn("w:tblInd"))
    if tblind is None:
        tblind = OxmlElement("w:tblInd")
        tblpr.append(tblind)
    tblind.set(qn("w:w"), str(TABLE_INDENT_DXA))
    tblind.set(qn("w:type"), "dxa")

    layout = tblpr.find(qn("w:tblLayout"))
    if layout is None:
        layout = OxmlElement("w:tblLayout")
        tblpr.append(layout)
    layout.set(qn("w:type"), "fixed")

    grid = table._tbl.tblGrid
    for child in list(grid):
        grid.remove(child)
    for width in widths:
        gridcol = OxmlElement("w:gridCol")
        gridcol.set(qn("w:w"), str(width))
        grid.append(gridcol)

    set_table_borders(table)
    set_repeat_table_header(table.rows[0])
    font_size = 8.25 if len(widths) >= 6 else 8.75
    for row_index, row in enumerate(table.rows):
        prevent_row_split(row)
        for column_index, cell in enumerate(row.cells):
            width = widths[column_index]
            cell.width = Twips(width)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            set_cell_margins(cell)
            tcpr = cell._tc.get_or_add_tcPr()
            tcw = tcpr.find(qn("w:tcW"))
            if tcw is None:
                tcw = OxmlElement("w:tcW")
                tcpr.append(tcw)
            tcw.set(qn("w:w"), str(width))
            tcw.set(qn("w:type"), "dxa")
            if row_index == 0:
                set_cell_shading(cell, CALLOUT)
            for paragraph in cell.paragraphs:
                paragraph.paragraph_format.space_before = Pt(0)
                paragraph.paragraph_format.space_after = Pt(0)
                paragraph.paragraph_format.line_spacing = 1.05
                paragraph.alignment = (
                    WD_ALIGN_PARAGRAPH.LEFT
                    if column_index == 0
                    else WD_ALIGN_PARAGRAPH.CENTER
                )
                for run in paragraph.runs:
                    run.font.name = "Calibri"
                    run.font.size = Pt(font_size)
                    if row_index == 0:
                        run.bold = True
                        run.font.color.rgb = RGBColor.from_string(NAVY)


def paragraph_has_drawing(paragraph) -> bool:
    return bool(paragraph._p.xpath(".//w:drawing"))


def prepend_caption_label(paragraph, label: str) -> None:
    """Prepend a styled label without flattening equations in the caption."""

    run = OxmlElement("w:r")
    properties = OxmlElement("w:rPr")
    bold = OxmlElement("w:b")
    italic = OxmlElement("w:i")
    italic.set(qn("w:val"), "0")
    color = OxmlElement("w:color")
    color.set(qn("w:val"), NAVY)
    properties.extend([bold, italic, color])
    run.append(properties)
    text = OxmlElement("w:t")
    text.set(qn("xml:space"), "preserve")
    text.text = f"{label} "
    run.append(text)

    ppr = paragraph._p.find(qn("w:pPr"))
    insert_at = 1 if ppr is not None else 0
    paragraph._p.insert(insert_at, run)


def postprocess_docx() -> None:
    doc = Document(DOCX_OUTPUT)
    set_page_geometry(doc)
    configure_reference_styles(doc)
    patch_numbering(doc)
    configure_headers_and_footers(doc)

    figure_number = 0
    table_number = 0
    in_conclusion = False
    for paragraph in doc.paragraphs:
        text = paragraph.text.strip()
        style_name = paragraph.style.name if paragraph.style else ""

        if text == "7. Conclusion":
            in_conclusion = True
        elif text == "Appendix A. Pointwise Proofs and Portfolio Cash Flows":
            in_conclusion = False

        if in_conclusion and not style_name.startswith("Heading"):
            paragraph.paragraph_format.space_after = Pt(6)
            paragraph.paragraph_format.line_spacing = 1.25

        if text.startswith("Distribution status."):
            paragraph.paragraph_format.page_break_before = True
        if text in {
            "References",
            "Appendix A. Pointwise Proofs and Portfolio Cash Flows",
        }:
            paragraph.paragraph_format.page_break_before = True

        if style_name == "Image Caption":
            figure_number += 1
            if not text.startswith("Figure "):
                paragraph.text = f"Figure {figure_number}. {text}"
            paragraph.style = get_or_add_style(doc, "Caption")
            paragraph.paragraph_format.keep_together = True
        elif style_name == "Table Caption":
            table_number += 1
            if not text.startswith("Table "):
                prepend_caption_label(paragraph, f"Table {table_number}.")
            paragraph.style = get_or_add_style(doc, "Table Caption")
            paragraph.paragraph_format.keep_with_next = True
            paragraph.paragraph_format.keep_together = True
        elif re.match(r"^Table\s+(?:\d+|[A-Z]\d+[a-z]?)\.\s", text):
            paragraph.style = get_or_add_style(doc, "Table Citation")
        elif re.match(r"^Figure\s+\d+\.\s", text):
            paragraph.style = get_or_add_style(doc, "Caption")

        if style_name in {"Block Text", "Quote"}:
            paragraph.style = get_or_add_style(doc, "Block Text")
            add_callout_treatment(paragraph)

        if text in {
            "Independent research project",
            "King's College London",
        } or "joshua.karat@kcl.ac.uk" in text:
            paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER

        if paragraph_has_drawing(paragraph):
            paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
            paragraph.paragraph_format.space_before = Pt(5)
            paragraph.paragraph_format.space_after = Pt(2)
            paragraph.paragraph_format.keep_with_next = True

        if style_name.startswith("Heading"):
            paragraph.paragraph_format.keep_with_next = True
            paragraph.paragraph_format.keep_together = True

    for shape in doc.inline_shapes:
        max_width = Inches(6.45)
        if shape.width > max_width:
            ratio = max_width / shape.width
            shape.width = max_width
            shape.height = int(shape.height * ratio)

    for table in doc.tables:
        format_table(table)

    doc.core_properties.author = "Joshua Karat"
    doc.core_properties.last_modified_by = "Joshua Karat"
    doc.core_properties.title = (
        "One Outcome, Two Prices? Rule-Verified No-Arbitrage and Price Discovery "
        "in Event-Contract Probability Surfaces"
    )
    doc.core_properties.subject = "Independent quantitative research paper"
    doc.core_properties.comments = (
        "Private research draft. See distribution notice in the document."
    )
    doc.save(DOCX_OUTPUT)


def build_docx() -> None:
    create_reference_docx()
    run(
        [
            "pandoc",
            str(SOURCE.name),
            "--from=markdown+tex_math_dollars",
            "--to=docx",
            "--citeproc",
            f"--bibliography={BIBLIOGRAPHY.name}",
            f"--reference-doc={REFERENCE_DOCX}",
            "--resource-path=.:..",
            f"--output={DOCX_OUTPUT}",
        ],
        cwd=PAPER,
    )
    postprocess_docx()


def build_pdf() -> None:
    environment = os.environ.copy()
    environment["TEXMFVAR"] = str(BUILD / "texmf-var")

    p052_match = subprocess.run(
        ["fc-match", "-f", "%{file}", "P052:style=Roman"],
        check=False,
        text=True,
        capture_output=True,
    )
    p052_roman = Path(p052_match.stdout.strip()) if p052_match.returncode == 0 else None
    p052_files = (
        "P052-Roman.otf",
        "P052-Bold.otf",
        "P052-Italic.otf",
        "P052-BoldItalic.otf",
    )
    if p052_roman and all((p052_roman.parent / name).is_file() for name in p052_files):
        font_directory = f"{p052_roman.parent.as_posix()}/"
        main_font_variables = [
            "--variable=mainfont:P052-Roman.otf",
            (
                "--variable=mainfontoptions:"
                f"Path={font_directory},"
                "BoldFont=P052-Bold.otf,"
                "ItalicFont=P052-Italic.otf,"
                "BoldItalicFont=P052-BoldItalic.otf"
            ),
        ]
    else:
        main_font_variables = ["--variable=mainfont:DejaVu Serif"]

    command = [
        "pandoc",
        str(SOURCE.name),
        "--from=markdown+tex_math_dollars",
        "--standalone",
        "--citeproc",
        f"--bibliography={BIBLIOGRAPHY.name}",
        "--pdf-engine=xelatex",
        "--pdf-engine-opt=-halt-on-error",
        "--resource-path=.:..",
        "--metadata=title:",
        "--metadata=subtitle:",
        "--metadata=author:",
        "--metadata=date:",
        "--variable=documentclass:article",
        "--variable=fontsize:11pt",
        "--variable=papersize:letter",
        "--variable=geometry:top=0.82in",
        "--variable=geometry:bottom=0.78in",
        "--variable=geometry:left=0.94in",
        "--variable=geometry:right=0.94in",
        *main_font_variables,
        "--variable=sansfont:DejaVu Sans",
        "--variable=monofont:DejaVu Sans Mono",
        "--variable=linestretch:1.10",
        f"--include-in-header={PAPER / 'header.tex'}",
        f"--include-before-body={PAPER / 'titlepage.tex'}",
        f"--output={PDF_OUTPUT}",
    ]
    completed = subprocess.run(
        command,
        cwd=PAPER,
        env=environment,
        check=False,
        text=True,
        capture_output=True,
    )
    if completed.returncode:
        raise RuntimeError(
            f"PDF build failed ({completed.returncode})\n"
            f"{completed.stdout}\n{completed.stderr}"
        )


def audit_pdf_content() -> dict[str, object]:
    completed = subprocess.run(
        ["pdftotext", "-layout", str(PDF_OUTPUT), "-"],
        check=False,
        text=True,
        capture_output=True,
    )
    if completed.returncode:
        raise RuntimeError(f"PDF text audit failed: {completed.stderr}")
    text = completed.stdout
    normalised_text = re.sub(r"\s+", " ", text)
    figure_numbers = sorted(
        {int(value) for value in re.findall(r"\bFigure\s+([0-9]+)\.", text)}
    )
    table_numbers = sorted(
        {int(value) for value in re.findall(r"\bTable\s+([0-9]+)\.", text)}
    )
    required = [
        "Figure 4.",
        "Table 6.",
        "half-life of 3.18 minutes",
        "[2.35,4.36]",
        "OLS, IV",
        "common-sample comparison",
        "-0.277",
        "Fieller interval",
        "50-100 cent band",
    ]
    forbidden = [
        "about 2.6 minutes",
        "N = 28,343 for IV",
    ]
    checks = {
        "figure_numbers": figure_numbers,
        "table_numbers": table_numbers,
        "figures_sequential": figure_numbers == list(range(1, 9)),
        "tables_sequential": table_numbers == list(range(1, 10)),
        "required_text_present": {
            value: value in normalised_text for value in required
        },
        "forbidden_text_absent": {
            value: value not in normalised_text for value in forbidden
        },
    }
    checks["passed"] = (
        checks["figures_sequential"]
        and checks["tables_sequential"]
        and all(checks["required_text_present"].values())
        and all(checks["forbidden_text_absent"].values())
    )
    (BUILD / "pdf_content_audit.json").write_text(
        json.dumps(checks, indent=2), encoding="utf-8"
    )
    if not checks["passed"]:
        raise RuntimeError(f"PDF content audit failed: {checks}")
    return checks


def audit_docx() -> dict[str, object]:
    doc = Document(DOCX_OUTPUT)
    section = doc.sections[0]
    text = "\n".join(paragraph.text for paragraph in doc.paragraphs)
    figure_numbers = [
        int(value) for value in re.findall(r"^Figure\s+([0-9]+)\.", text, re.MULTILINE)
    ]
    table_numbers = [
        int(value) for value in re.findall(r"^Table\s+([0-9]+)\.", text, re.MULTILINE)
    ]
    checks = {
        "letter_width": round(section.page_width / 914400, 4) == 8.5,
        "letter_height": round(section.page_height / 914400, 4) == 11.0,
        "margin_top": round(section.top_margin / 914400, 4) == 1.0,
        "margin_right": round(section.right_margin / 914400, 4) == 1.0,
        "margin_bottom": round(section.bottom_margin / 914400, 4) == 1.0,
        "margin_left": round(section.left_margin / 914400, 4) == 1.0,
        "header_distance": abs(section.header_distance / 914400 - 0.492) < 0.002,
        "footer_distance": abs(section.footer_distance / 914400 - 0.492) < 0.002,
        "normal_font": doc.styles["Normal"].font.name == "Calibri",
        "normal_size": doc.styles["Normal"].font.size.pt == 11,
        "table_count": len(doc.tables),
        "figure_count": len(doc.inline_shapes),
        "paragraph_count": len(doc.paragraphs),
        "figure_numbers": figure_numbers,
        "table_numbers": table_numbers,
        "figures_sequential": figure_numbers == list(range(1, 9)),
        "tables_sequential": table_numbers == list(range(1, 10)),
    }
    table_widths = []
    for table in doc.tables:
        tblw = table._tbl.tblPr.find(qn("w:tblW"))
        value = int(tblw.get(qn("w:w"))) if tblw is not None else 0
        table_widths.append(value)
    checks["all_tables_9360_dxa"] = all(
        value == CONTENT_WIDTH_DXA for value in table_widths
    )
    checks["table_widths"] = table_widths
    checks["passed"] = all(
        value is True
        for key, value in checks.items()
        if key
        not in {
            "table_count",
            "figure_count",
            "paragraph_count",
            "table_widths",
            "figure_numbers",
            "table_numbers",
        }
    )
    (BUILD / "docx_audit.json").write_text(
        json.dumps(checks, indent=2), encoding="utf-8"
    )
    if not checks["passed"]:
        raise RuntimeError(f"DOCX preset audit failed: {checks}")
    return checks


def main() -> None:
    BUILD.mkdir(parents=True, exist_ok=True)
    OUTPUT.mkdir(parents=True, exist_ok=True)
    build_docx()
    build_pdf()
    docx_audit = audit_docx()
    pdf_audit = audit_pdf_content()
    print(
        json.dumps(
            {
                "docx": str(DOCX_OUTPUT),
                "pdf": str(PDF_OUTPUT),
                "docx_audit": docx_audit,
                "pdf_audit": pdf_audit,
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
