# Distribution and Data-Use Notice

This package is a private research draft prepared by Joshua Karat. It is not
affiliated with or endorsed by Kalshi.

The study uses exchange API data. Kalshi's Developer Agreement restricts API
use and third-party data sharing or public disclosures relating to the API.
Before any public release, repository publication, application attachment, or
third-party distribution, obtain any required prior written authorisation and
re-check the then-current terms:

- Developer Agreement:
  https://assets.kalshi.com/Kalshi-Developer-Agreement.pdf
- Market candlestick documentation:
  https://docs.kalshi.com/api-reference/market/get-market-candlesticks
- Historical-data documentation:
  https://docs.kalshi.com/getting_started/historical_data
- Fee schedule:
  https://kalshi.com/docs/kalshi-fee-schedule.pdf

The distributable archive excludes cached API responses, normalised row-level
quotes, row-level matched state panels, row-level forecast samples, API keys,
tokens, and credentials. It contains source code, tests, aggregate tables,
figures, the results manifest, and the research paper.

Nothing in this notice is legal advice.
