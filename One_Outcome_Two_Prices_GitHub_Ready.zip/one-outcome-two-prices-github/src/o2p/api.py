"""Small, dependency-free client for Kalshi's public market-data API."""

from __future__ import annotations

import gzip
import json
import random
import threading
import time
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen


BASE_URL = "https://external-api.kalshi.com/trade-api/v2"


class RateLimiter:
    """Thread-safe minimum-spacing limiter."""

    def __init__(self, requests_per_second: float = 15.0) -> None:
        self._minimum_gap = 1.0 / requests_per_second
        self._lock = threading.Lock()
        self._last_request = 0.0

    def wait(self) -> None:
        with self._lock:
            now = time.monotonic()
            delay = self._minimum_gap - (now - self._last_request)
            if delay > 0:
                time.sleep(delay)
            self._last_request = time.monotonic()


class KalshiPublicClient:
    """Read-only client with retries, throttling, and optional gzip caching."""

    def __init__(
        self,
        base_url: str = BASE_URL,
        requests_per_second: float = 15.0,
        timeout: int = 45,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.limiter = RateLimiter(requests_per_second)

    def get_json(
        self,
        path: str,
        params: dict[str, Any] | None = None,
        cache_path: Path | None = None,
        retries: int = 6,
    ) -> dict[str, Any]:
        if cache_path is not None and cache_path.exists():
            with gzip.open(cache_path, "rt", encoding="utf-8") as handle:
                return json.load(handle)

        query = urlencode(params or {}, doseq=True, safe=",")
        url = f"{self.base_url}/{path.lstrip('/')}"
        if query:
            url = f"{url}?{query}"

        last_error: Exception | None = None
        for attempt in range(retries):
            self.limiter.wait()
            request = Request(
                url,
                headers={
                    "Accept": "application/json",
                    "User-Agent": "OneOutcomeTwoPrices-Research/1.0",
                },
            )
            try:
                with urlopen(request, timeout=self.timeout) as response:
                    payload = json.loads(response.read().decode("utf-8"))
                if cache_path is not None:
                    cache_path.parent.mkdir(parents=True, exist_ok=True)
                    temporary = cache_path.with_suffix(cache_path.suffix + ".tmp")
                    with gzip.open(temporary, "wt", encoding="utf-8") as handle:
                        json.dump(payload, handle, separators=(",", ":"))
                    temporary.replace(cache_path)
                return payload
            except HTTPError as exc:
                last_error = exc
                if exc.code not in {408, 429, 500, 502, 503, 504}:
                    raise
                retry_after = exc.headers.get("Retry-After")
                if retry_after:
                    try:
                        delay = float(retry_after)
                    except ValueError:
                        delay = 0.0
                else:
                    delay = 0.0
            except (URLError, TimeoutError, json.JSONDecodeError) as exc:
                last_error = exc
                delay = 0.0

            if attempt < retries - 1:
                backoff = max(delay, min(20.0, 0.75 * (2**attempt)))
                time.sleep(backoff + random.random() * 0.25)

        raise RuntimeError(f"GET failed after {retries} attempts: {url}") from last_error

