"""Payoff matching, quote algebra, fees, and constrained reconciliation."""

from __future__ import annotations

import math
from dataclasses import dataclass
from decimal import Decimal, ROUND_CEILING
from typing import Any, Iterable

import numpy as np
from scipy.optimize import linprog, minimize


TOLERANCE = 1e-6


def _number(value: Any) -> float | None:
    if value in (None, ""):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _market_volume(market: dict[str, Any]) -> float:
    return _number(market.get("volume_fp", market.get("volume"))) or 0.0


def _market_open_interest(market: dict[str, Any]) -> float:
    return _number(market.get("open_interest_fp", market.get("open_interest"))) or 0.0


def _threshold_lookup(markets: Iterable[dict[str, Any]]) -> dict[int, dict[str, Any]]:
    lookup: dict[int, dict[str, Any]] = {}
    for market in markets:
        floor = _number(market.get("floor_strike"))
        if floor is None:
            continue
        rounded = int(round(floor))
        if abs(floor - rounded) <= 0.02:
            lookup[rounded] = market
    return lookup


def _range_order(market: dict[str, Any]) -> tuple[float, float]:
    strike_type = market.get("strike_type")
    if strike_type == "less":
        return (-math.inf, _number(market.get("cap_strike")) or math.inf)
    if strike_type == "greater":
        return (_number(market.get("floor_strike")) or -math.inf, math.inf)
    return (
        _number(market.get("floor_strike")) or -math.inf,
        _number(market.get("cap_strike")) or math.inf,
    )


def match_contracts(
    range_event: dict[str, Any],
    threshold_event: dict[str, Any],
    index_name: str,
) -> tuple[list[dict[str, Any]], list[str]]:
    """Match every range state to its exact threshold representation."""

    range_obj = range_event.get("event", range_event)
    threshold_obj = threshold_event.get("event", threshold_event)
    warnings: list[str] = []

    if range_obj.get("strike_date") != threshold_obj.get("strike_date"):
        warnings.append("strike_date_mismatch")
    if range_obj.get("sub_title") != threshold_obj.get("sub_title"):
        warnings.append("subtitle_mismatch")

    range_markets = sorted(range_obj.get("markets", []), key=_range_order)
    threshold_markets = threshold_obj.get("markets", [])
    threshold_by_level = _threshold_lookup(threshold_markets)

    matches: list[dict[str, Any]] = []
    for state_index, direct in enumerate(range_markets):
        strike_type = direct.get("strike_type")
        low_level: int | None = None
        high_level: int | None = None
        state_kind: str

        if strike_type == "less":
            cap = _number(direct.get("cap_strike"))
            high_level = int(round(cap)) if cap is not None else None
            state_kind = "left_tail"
        elif strike_type == "between":
            floor = _number(direct.get("floor_strike"))
            cap = _number(direct.get("cap_strike"))
            low_level = int(round(floor)) if floor is not None else None
            high_level = int(math.floor((cap or 0.0) + 1e-8)) + 1
            state_kind = "interior"
        elif strike_type == "greater":
            floor = _number(direct.get("floor_strike"))
            low_level = int(round(floor)) if floor is not None else None
            state_kind = "right_tail"
        else:
            warnings.append(f"unsupported_strike_type:{direct.get('ticker')}:{strike_type}")
            continue

        low_market = threshold_by_level.get(low_level) if low_level is not None else None
        high_market = threshold_by_level.get(high_level) if high_level is not None else None
        missing = (
            (state_kind in {"interior", "right_tail"} and low_market is None)
            or (state_kind in {"interior", "left_tail"} and high_market is None)
        )
        if missing:
            warnings.append(
                f"missing_threshold:{direct.get('ticker')}:{low_level}:{high_level}"
            )
            continue

        result = str(direct.get("result", "")).lower()
        outcome = 1 if result == "yes" else (0 if result == "no" else None)
        matches.append(
            {
                "index_name": index_name,
                "event_ticker": range_obj.get("event_ticker"),
                "threshold_event_ticker": threshold_obj.get("event_ticker"),
                "strike_date": range_obj.get("strike_date"),
                "event_subtitle": range_obj.get("sub_title"),
                "state_index": state_index,
                "state_kind": state_kind,
                "low_level": low_level,
                "high_level": high_level,
                "direct_ticker": direct.get("ticker"),
                "low_ticker": low_market.get("ticker") if low_market else None,
                "high_ticker": high_market.get("ticker") if high_market else None,
                "direct_rules": direct.get("rules_primary"),
                "low_rules": low_market.get("rules_primary") if low_market else None,
                "high_rules": high_market.get("rules_primary") if high_market else None,
                "direct_volume": _market_volume(direct),
                "low_volume": _market_volume(low_market or {}),
                "high_volume": _market_volume(high_market or {}),
                "direct_open_interest": _market_open_interest(direct),
                "low_open_interest": _market_open_interest(low_market or {}),
                "high_open_interest": _market_open_interest(high_market or {}),
                "outcome": outcome,
                "direct_status": direct.get("status"),
                "direct_close_time": direct.get("close_time"),
                "direct_settlement_ts": direct.get("settlement_ts"),
                "direct_expiration_value": direct.get("expiration_value"),
                "n_legs": 3 if state_kind == "interior" else 2,
            }
        )

    if matches and sum(int(row["outcome"] or 0) for row in matches) != 1:
        warnings.append("outcomes_not_one_hot")
    return matches, warnings


def range_state_rows(
    range_event: dict[str, Any],
    index_name: str,
) -> list[dict[str, Any]]:
    """Return the exchange's full mutually exclusive range partition."""

    range_obj = range_event.get("event", range_event)
    markets = sorted(range_obj.get("markets", []), key=_range_order)
    rows: list[dict[str, Any]] = []
    for state_index, market in enumerate(markets):
        strike_type = market.get("strike_type")
        floor = _number(market.get("floor_strike"))
        cap = _number(market.get("cap_strike"))
        if strike_type == "less":
            state_kind = "left_tail"
            low_level = None
            high_level = int(round(cap)) if cap is not None else None
        elif strike_type == "greater":
            state_kind = "right_tail"
            low_level = int(round(floor)) if floor is not None else None
            high_level = None
        else:
            state_kind = "interior"
            low_level = int(round(floor)) if floor is not None else None
            high_level = (
                int(math.floor((cap or 0.0) + 1e-8)) + 1
                if cap is not None
                else None
            )
        result = str(market.get("result", "")).lower()
        outcome = 1 if result == "yes" else (0 if result == "no" else None)
        rows.append(
            {
                "index_name": index_name,
                "event_ticker": range_obj.get("event_ticker"),
                "strike_date": range_obj.get("strike_date"),
                "state_index": state_index,
                "state_kind": state_kind,
                "low_level": low_level,
                "high_level": high_level,
                "direct_ticker": market.get("ticker"),
                "direct_rules": market.get("rules_primary"),
                "direct_volume": _market_volume(market),
                "direct_open_interest": _market_open_interest(market),
                "outcome": outcome,
                "direct_status": market.get("status"),
                "direct_close_time": market.get("close_time"),
                "direct_settlement_ts": market.get("settlement_ts"),
                "direct_expiration_value": market.get("expiration_value"),
            }
        )
    return rows


@dataclass(frozen=True)
class Quote:
    bid: float
    ask: float

    @property
    def mid(self) -> float:
        return 0.5 * (self.bid + self.ask)

    @property
    def spread(self) -> float:
        return self.ask - self.bid


def synthetic_quote(
    state_kind: str,
    low_quote: Quote | None,
    high_quote: Quote | None,
) -> Quote:
    """Executable bid/ask bounds for the threshold-spanned state claim."""

    if state_kind == "left_tail":
        if high_quote is None:
            raise ValueError("left tail requires a high-threshold quote")
        return Quote(bid=1.0 - high_quote.ask, ask=1.0 - high_quote.bid)
    if state_kind == "right_tail":
        if low_quote is None:
            raise ValueError("right tail requires a low-threshold quote")
        return low_quote
    if state_kind == "interior":
        if low_quote is None or high_quote is None:
            raise ValueError("interior state requires both threshold quotes")
        return Quote(
            bid=low_quote.bid - high_quote.ask,
            ask=low_quote.ask - high_quote.bid,
        )
    raise ValueError(f"unsupported state kind: {state_kind}")


def quoted_lock(direct_quote: Quote, synthetic: Quote) -> tuple[float, str]:
    """Positive separation between quote intervals, before fees."""

    buy_direct = synthetic.bid - direct_quote.ask
    buy_synthetic = direct_quote.bid - synthetic.ask
    if buy_direct >= buy_synthetic and buy_direct > 0:
        return buy_direct, "buy_direct_sell_synthetic"
    if buy_synthetic > 0:
        return buy_synthetic, "buy_synthetic_sell_direct"
    return 0.0, "none"


def direct_member_fee(price: float, contracts: float = 1.0, multiplier: float = 1.0) -> float:
    """July 2026 general taker fee, rounded up to the nearest centicent."""

    p = Decimal(str(min(max(price, 0.0), 1.0)))
    raw = Decimal(str(multiplier)) * Decimal("0.07") * Decimal(str(contracts)) * p * (1 - p)
    return float(raw.quantize(Decimal("0.0001"), rounding=ROUND_CEILING))


def maker_fee(
    price: float,
    contracts: float = 1.0,
    multiplier: float = 0.0,
) -> float:
    """July 2026 maker fee; the general-market multiplier defaults to zero."""

    p = Decimal(str(min(max(price, 0.0), 1.0)))
    raw = (
        Decimal(str(multiplier))
        * Decimal("0.0175")
        * Decimal(str(contracts))
        * p
        * (1 - p)
    )
    return float(raw.quantize(Decimal("0.0001"), rounding=ROUND_CEILING))


def non_direct_member_fee(price: float) -> float:
    """One-lot taker fee at the non-direct-member whole-cent balance precision."""

    p = Decimal(str(min(max(price, 0.0), 1.0)))
    raw = Decimal("0.07") * p * (1 - p)
    if raw == 0:
        return 0.0
    return float(raw.quantize(Decimal("0.01"), rounding=ROUND_CEILING))


def project_simplex(vector: np.ndarray) -> np.ndarray:
    """Euclidean projection onto the unit simplex."""

    values = np.asarray(vector, dtype=float)
    if values.ndim != 1:
        raise ValueError("simplex projection expects a one-dimensional vector")
    if values.size == 0:
        return values.copy()
    ordered = np.sort(values)[::-1]
    cumulative = np.cumsum(ordered) - 1.0
    indices = np.arange(1, values.size + 1)
    positive = ordered - cumulative / indices > 0
    rho = int(np.nonzero(positive)[0][-1])
    theta = cumulative[rho] / float(rho + 1)
    return np.maximum(values - theta, 0.0)


@dataclass(frozen=True)
class SurfaceConsistency:
    """Result of the joint bid-ask consistent-price-system test."""

    feasible: bool
    minimum_uniform_slack: float
    coherent_distribution: np.ndarray


def consistent_price_system(
    direct_bids: np.ndarray,
    direct_asks: np.ndarray,
    threshold_bids: np.ndarray,
    threshold_asks: np.ndarray,
    *,
    tolerance: float = 1e-9,
) -> SurfaceConsistency:
    """Test whether every quote interval admits one coherent state distribution.

    A K-state range partition has K-1 internal threshold claims. Threshold j is
    the survival probability of states j+1 through K-1. The linear programme
    finds the smallest common outward expansion of every bid-ask interval that
    permits a non-negative state vector summing to one. A zero optimum is a
    joint consistent price system.
    """

    direct_bids = np.asarray(direct_bids, dtype=float)
    direct_asks = np.asarray(direct_asks, dtype=float)
    threshold_bids = np.asarray(threshold_bids, dtype=float)
    threshold_asks = np.asarray(threshold_asks, dtype=float)
    k_states = direct_bids.size
    if direct_asks.shape != direct_bids.shape:
        raise ValueError("direct bid and ask vectors must have the same shape")
    if threshold_bids.size != k_states - 1 or threshold_asks.size != k_states - 1:
        raise ValueError("a K-state partition needs K-1 threshold quote intervals")
    arrays = (direct_bids, direct_asks, threshold_bids, threshold_asks)
    if k_states == 0 or any(array.ndim != 1 for array in arrays):
        raise ValueError("surface quotes must be non-empty one-dimensional vectors")
    if any(not np.all(np.isfinite(array)) for array in arrays):
        raise ValueError("surface quotes must be finite")
    if np.any(direct_bids > direct_asks) or np.any(threshold_bids > threshold_asks):
        raise ValueError("surface bids cannot exceed asks")
    if any(np.any((array < 0) | (array > 1)) for array in arrays):
        raise ValueError("component quote intervals must lie in [0, 1]")

    survival = np.zeros((k_states - 1, k_states), dtype=float)
    for boundary in range(k_states - 1):
        survival[boundary, boundary + 1 :] = 1.0

    identity = np.eye(k_states)
    # Decision vector is (q_1, ..., q_K, epsilon). Every interval expands by
    # epsilon on both sides; q itself remains a probability distribution.
    inequalities = np.vstack(
        [
            np.column_stack([identity, -np.ones(k_states)]),
            np.column_stack([-identity, -np.ones(k_states)]),
            np.column_stack([survival, -np.ones(k_states - 1)]),
            np.column_stack([-survival, -np.ones(k_states - 1)]),
        ]
    )
    limits = np.concatenate(
        [direct_asks, -direct_bids, threshold_asks, -threshold_bids]
    )
    objective = np.concatenate([np.zeros(k_states), np.ones(1)])
    equality = np.concatenate([np.ones(k_states), np.zeros(1)])[None, :]
    result = linprog(
        objective,
        A_ub=inequalities,
        b_ub=limits,
        A_eq=equality,
        b_eq=np.ones(1),
        bounds=[(0.0, 1.0)] * k_states + [(0.0, None)],
        method="highs",
    )
    if not result.success:
        raise RuntimeError(f"surface consistency programme failed: {result.message}")
    slack = max(0.0, float(result.x[-1]))
    distribution = project_simplex(np.asarray(result.x[:-1], dtype=float))
    return SurfaceConsistency(
        feasible=slack <= tolerance,
        minimum_uniform_slack=slack,
        coherent_distribution=distribution,
    )


def fused_distribution(
    direct: np.ndarray,
    thresholds: np.ndarray,
    direct_spreads: np.ndarray,
    threshold_spreads: np.ndarray,
) -> np.ndarray:
    """Reconcile direct state prices and threshold survival prices.

    `thresholds[j]` is P(state index >= j+1), so a K-state distribution has
    K-1 internal threshold observations.
    """

    direct = np.asarray(direct, dtype=float)
    thresholds = np.asarray(thresholds, dtype=float)
    k_states = direct.size
    if thresholds.size != k_states - 1:
        raise ValueError("a K-state distribution needs K-1 internal thresholds")

    direct_spreads = np.asarray(direct_spreads, dtype=float)
    threshold_spreads = np.asarray(threshold_spreads, dtype=float)
    w_direct = 1.0 / np.square(np.clip(direct_spreads, 0.01, 0.25))
    w_threshold = 1.0 / np.square(np.clip(threshold_spreads, 0.01, 0.25))
    w_direct = np.clip(w_direct, 16.0, 10_000.0)
    w_threshold = np.clip(w_threshold, 16.0, 10_000.0)

    available_direct = np.isfinite(direct)
    available_threshold = np.isfinite(thresholds)
    if not np.any(available_direct) and not np.any(available_threshold):
        return np.full(k_states, 1.0 / k_states)

    survival = np.zeros((k_states - 1, k_states), dtype=float)
    for boundary in range(k_states - 1):
        survival[boundary, boundary + 1 :] = 1.0

    design_blocks: list[np.ndarray] = []
    target_blocks: list[np.ndarray] = []
    if np.any(available_direct):
        design_blocks.append(
            np.sqrt(w_direct[available_direct])[:, None]
            * np.eye(k_states)[available_direct]
        )
        target_blocks.append(
            np.sqrt(w_direct[available_direct]) * direct[available_direct]
        )
    if np.any(available_threshold):
        design_blocks.append(
            np.sqrt(w_threshold[available_threshold])[:, None]
            * survival[available_threshold]
        )
        target_blocks.append(
            np.sqrt(w_threshold[available_threshold])
            * thresholds[available_threshold]
        )
    design = np.vstack(design_blocks)
    target = np.concatenate(target_blocks)

    # Scaling and an analytic gradient materially improve SLSQP stability when
    # one-cent spreads create weights four orders of magnitude apart.
    scale = max(float(np.linalg.norm(design, ord=2)), 1.0)
    design = design / scale
    target = target / scale

    def objective(q: np.ndarray) -> float:
        residual = design @ q - target
        return float(residual @ residual)

    def gradient(q: np.ndarray) -> np.ndarray:
        return 2.0 * design.T @ (design @ q - target)

    starts = [project_simplex(np.nan_to_num(direct, nan=0.0))]
    if np.all(available_threshold):
        threshold_states = np.concatenate(
            [
                [1.0 - thresholds[0]],
                thresholds[:-1] - thresholds[1:],
                [thresholds[-1]],
            ]
        )
        starts.append(project_simplex(threshold_states))
    starts.append(np.full(k_states, 1.0 / k_states))

    candidates = []
    for initial in starts:
        result = minimize(
            objective,
            initial,
            method="SLSQP",
            jac=gradient,
            bounds=[(0.0, 1.0)] * k_states,
            constraints=[
                {
                    "type": "eq",
                    "fun": lambda q: float(np.sum(q) - 1.0),
                    "jac": lambda q: np.ones_like(q),
                }
            ],
            options={"ftol": 1e-12, "maxiter": 2_000},
        )
        if result.success and abs(float(np.sum(result.x)) - 1.0) <= 1e-7:
            candidates.append(result)
    if not candidates:
        raise RuntimeError("distribution reconciliation failed from all starts")
    best = min(candidates, key=lambda result: objective(result.x))
    return project_simplex(best.x)


def quote_leg_prices(
    direction: str,
    state_kind: str,
    direct: Quote,
    low: Quote | None,
    high: Quote | None,
) -> list[float]:
    """Prices entering the fee calculation for a quoted-lock direction."""

    if direction == "none":
        return []
    if direction == "buy_direct_sell_synthetic":
        prices = [direct.ask]
        if state_kind == "interior":
            assert low is not None and high is not None
            prices.extend([low.bid, high.ask])
        elif state_kind == "left_tail":
            assert high is not None
            prices.append(1.0 - high.ask)
        else:
            assert low is not None
            prices.append(low.bid)
        return prices

    prices = [direct.bid]
    if state_kind == "interior":
        assert low is not None and high is not None
        prices.extend([low.ask, high.bid])
    elif state_kind == "left_tail":
        assert high is not None
        prices.append(1.0 - high.bid)
    else:
        assert low is not None
        prices.append(low.ask)
    return prices
