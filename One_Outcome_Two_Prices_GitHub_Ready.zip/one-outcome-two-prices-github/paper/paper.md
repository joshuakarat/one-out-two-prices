---
title: "One Outcome, Two Prices?"
subtitle: "Rule-Verified No-Arbitrage and Price Discovery in Event-Contract Probability Surfaces"
author: "Joshua Karat"
date: "1 August 2026"
bibliography: "references.bib"
link-citations: true
reference-section-title: "References"
lang: "en-GB"
---

> **Distribution status.** Private research draft. The analysis uses Kalshi API data. Kalshi's Developer Agreement restricts API-data use and public disclosures relating to the API; written authorisation should be obtained before public release or third-party distribution. No raw exchange data are included in the distributable project archive.

# Abstract

The data do not establish an exploitable arbitrage. They do reveal, unusually cleanly, how a fragmented market repairs two prices for the same terminal payoff.

I study daily S&P 500 and Nasdaq-100 event contracts in which a mutually exclusive range claim is exactly replicated by adjacent nested threshold claims. Contract rules, rather than title similarity, identify the pointwise payoff relation. The sample contains 2,106 matched states across 86 settled events on 43 trading dates and 64,819 same-minute, all-leg quote observations. That row count is concentrated: the median event-state contributes four minutes, and an inverse-Herfindahl coverage measure is 556 event-states rather than the 1,951 observed.

Direct and threshold-implied midpoints have correlation 0.9913 and a median absolute gap of one cent. Quote intervals are positively separated in 862 state-minutes (1.330%) before fees. Excluding the scheduled-close candle converts 849 positive minutes into 607 episodes. Direct-member taker fees leave 280 episodes; non-direct-member whole-cent fee precision leaves five episodes across three events. These are conditional quote screens, not realised trades. Candidate composition is also price-dependent: in the full panel, 40.3% of gross and 74.5% of direct-member all-taker candidates have reference midpoints at or below five cents, while none of the non-direct positives do.

A conventional error-correction model is vulnerable because the lagged direct quote appears in the regressor and the dependent change with opposite signs. Under a simulated pure-noise null, OLS mechanically estimates about -0.5 for the direct response and +0.5 for the synthetic response. Re-estimating OLS on the exact 25,529-row IV sample gives -0.277 and +0.319, versus -0.333 and +0.358 in the full primary sample: at the point estimates, sample selection explains about one fifth of the reduction in total adjustment and the estimator change four fifths. I instrument the lagged gap with its second and third lags. The joint first stage is strong (date-clustered F = 276.8; simulated noise-null 95th percentile = 3.41), and equation-specific Hansen tests do not reject the overidentifying restriction. IV estimates a direct response of -0.151 and a synthetic response of +0.045; only the former is precisely different from zero. The implied gap half-life is 3.2 minutes with a date-cluster bootstrap interval of [2.35,4.36]; imposing the sensitivity $\alpha_S=0$ gives 4.2 minutes. The 23.0% direct-component point estimate suggests that threshold books may lead, although bootstrap and Fieller intervals cannot exclude parity. A two-state placebo destroys alignment and reduces total OLS gap repair from 69.1% to 1.0% per minute.

Across 68 complete 30-state snapshots, I find no executable direct-package or threshold-monotonicity violation. A stricter joint linear programme nevertheless finds that 19 of 53 fixed-horizon surfaces need a quote relaxation, never exceeding one cent. Forecast reconciliation produces no robust proper-score improvement. Direct quotes show the textbook two-tail direction of favourite-longshot bias, but the favourite bin has only 13 observations and cannot establish the high-side leg. The contribution is therefore not a backtested strategy. It is a rule-verified, within-exchange identification design for auditing no-arbitrage, microstructure, and price discovery without estimating fundamental value.

**Keywords:** prediction markets; law of one price; price discovery; market microstructure; state prices; instrumental variables; forecast evaluation

**JEL:** G14; G13; D84; C58

# 1. Introduction

When two assets have identical payoffs in every terminal state, their price difference is economically interpretable without a model of fair value. That is the attraction of put-call parity, cash-and-carry relations, and other relative-value designs. Prediction markets offer a particularly transparent version: contracts pay either zero or one dollar, and the settlement rule describes the states directly.

They also create a difficult empirical problem. Two contracts that sound equivalent may differ in oracle, deadline, rounding, cancellation rule, collateral, or legal claim. Cross-platform comparisons therefore mix pricing with semantic and institutional non-fungibility [@gebele2026]. This paper removes that ambiguity. It compares claims on the same exchange, settling at the same time on the same reported index value, and verifies equivalence algebraically from structured contract rules.

The question is deliberately narrow:

> When one event outcome trades in two payoff-equivalent representations, how coherent are the quotes, which representation repairs a persistent gap, and does reconciliation improve forecasts?

The study connects three literatures. Prediction-market prices can aggregate dispersed information, but their interpretation as physical probabilities depends on equilibrium conditions and market composition [@wolfers2004; @manski2006]; recent work uses regulated event contracts to recover high-frequency macroeconomic expectations [@diercks2026]. Probabilistic coherence research asks whether quoted beliefs satisfy logical restrictions, while recent prediction-market studies distinguish formal arbitrage from tradable edge after frictions [@predd2009; @saguillo2025; @ogiermann2026]. Finally, error correction and common-factor methods attribute price discovery across redundant venues or securities [@engle1987; @hasbrouck1995; @gonzalo1995], including emerging work on modern prediction markets [@ng2026]. The contribution here is sharper than a new combination of familiar tools: within-exchange rule-verified payoff replication removes the semantic-equivalence problem before coherence or price discovery is estimated.

The setting pairs mutually exclusive *range* claims with nested *threshold* claims. If the reported terminal index is $S_T$ and $K_i<K_{i+1}$, then

$$
\mathbf{1}\{K_i\leq S_T<K_{i+1}\}
=
\mathbf{1}\{S_T\geq K_i\}
-
\mathbf{1}\{S_T\geq K_{i+1}\}. \tag{1}
$$

Equation (1) is exact for every $S_T$. It is not a statistical fit, a text match, or a claim that market prices equal physical probabilities. It creates a model-free benchmark for quote coherence.

The paper makes four contributions.

First, it uses within-exchange, rule-verified payoff replication as an identification strategy. This directly addresses the semantic-equivalence problem that weakens many cross-market law-of-one-price tests. The state map includes both tails, exact interval boundaries, settlement time, index source, and realised outcome; approximate matches are rejected.

Second, it separates midpoint disagreement, an executable-looking separation of top-of-book intervals, and realised profit. Synthetic bids and asks use the correct side of every component book. Fees are applied leg by leg under direct-member and non-direct-member balance precision, with explicit maker-leg sensitivities. Repeated positive minutes are collapsed into contiguous episodes, and cash return is calculated for complementary-claim implementations with fixed terminal payout.

Third, it corrects a subtle identification failure in the price-discovery regression. The conventional lagged gap shares a noisy lagged quote with the dependent price change. That construction can manufacture a negative direct adjustment and a positive synthetic adjustment even when the latent price is constant. Second- and third-lag instruments remove the shared observation under serially uncorrelated quote noise. Their joint first-stage strength distinguishes persistent gaps from the white-noise null; the extra lag also makes the exclusion restriction partially testable. Inference clusters the two same-date index events together and uses wild-cluster procedures suited to 43 date clusters [@cameron2008].

Fourth, it expands pairwise parity into a coherence audit. Direct range asks should sum to at least one and bids to at most one; higher-strike thresholds should never be executable above lower-strike thresholds; and one probability vector should jointly fit every direct and threshold quote interval. Calibration and proper-score comparisons test whether removing incoherence improves forecasting rather than assuming that it must.

The results reject the easy story. Direct and replicated prices are close, with 0.9913 correlation and a one-cent median absolute gap, but the panel's nominal size overstates its breadth. The median matched state is observed for four minutes, and the most continuously quoted 10% of event-states generate 48.4% of all rows. Positive interval separation occurs in 1.330% of rows before fees. In the stricter pre-close sample it becomes 607 episodes, then 280 under direct-member all-taker fees and five under non-direct-member whole-cent precision. Historical candles cannot reveal atomic availability, depth, queue position, or fills, so none is labelled realised arbitrage.

Price level changes the interpretation. Low-price claims are mechanically coarse because the minimum quote increment is large relative to value. Gross candidates do not live exclusively in the tail, but direct-member all-taker candidates do concentrate there: 74.5% have a reference midpoint no greater than five cents. Conversely, all five pre-close non-direct episodes occur above five cents. The honest result is conditional, not rhetorical: discreteness explains much of one fee screen, but not every surviving configuration.

The dynamic result changes materially under identification. OLS estimates that the direct midpoint repairs 33.3% and the synthetic midpoint 35.8% of a lagged gap in the next minute. On the exact IV sample those responses are 27.7% and 31.9%, so non-random loss of short quote runs explains some, but not most, of the difference. A pure independent-noise simulation produces the more extreme but entirely mechanical pair of -0.5 and +0.5. Instrumenting with the second and third lags yields -0.151 for the direct price and +0.045 for the synthetic price. The direct response is robust; the synthetic response is not precisely different from zero. The implied half-life is 3.2 minutes with a [2.35,4.36] date-cluster bootstrap interval; setting the imprecise synthetic response to zero lengthens it to 4.2 minutes. The 23.0% direct-component point estimate is economically consistent with threshold books leading, but its ratio-robust intervals include one half. The direction is suggestive, not dispositive.

Two falsifications strengthen that interpretation. In 999 pure-noise simulations, the joint first-stage F statistic never approaches the observed 276.8; the simulated 95th percentile is 3.41. Deliberately pairing each range with a synthetic state two bins away changes contemporaneous correlation from 0.985 on the overlap to -0.058 and raises mean absolute error from 1.26 to 14.44 cents. Its total next-minute OLS adjustment is only 1.0% of the wrong-state gap. The exact rule map is therefore doing substantive work.

The full-surface results are equally informative. Across every one of 68 synchronous 30-state snapshots, direct partition quotes admit the one-dollar package bound and threshold quotes satisfy executable monotonicity. At the fixed 180-minute horizon, however, only 34 of 53 surfaces admit one non-negative unit-sum distribution inside all recorded quote intervals simultaneously. The remaining 19 require a uniform relaxation of at most one cent; 11 failures have no pairwise gross candidate. This is evidence of small joint quote-system tension, not a 30-leg executable trade.

Finally, reconciliation does not create a forecasting edge. On a strictly balanced panel of 278 event-state pairs across 59 events, neither the threshold representation nor a spread-weighted fusion beats the direct quote on Brier or log score at 120, 60, 30, or 10 minutes with a credible paired-event interval. Complete-surface projection and fusion likewise fail to improve Brier, log, or ranked probability score robustly. The negative result is useful: redundancy is most valuable here as an internal control, not as a free forecast ensemble.

# 2. Payoff Algebra and No-Arbitrage Restrictions

## 2.1 Two representations of one state

Let $K_1<\cdots<K_J$ be ordered boundaries and define the threshold claim

$$
U_i=\mathbf{1}\{S_T\geq K_i\}.
$$

For an interior interval, define

$$
R_i=\mathbf{1}\{K_i\leq S_T<K_{i+1}\}.
$$

Because the events are nested, $R_i=U_i-U_{i+1}$ pointwise. The tails are also exact:

$$
R_0=\mathbf{1}\{S_T<K_1\}=1-U_1,
\qquad
R_J=\mathbf{1}\{S_T\geq K_J\}=U_J. \tag{2}
$$

The complement in the left tail matters. A synthetically purchased interior range is implemented as a YES on $U_i$ plus a NO on $U_{i+1}$; its terminal cash flow is $1+R_i$, not merely $R_i$. The extra certain dollar appears on both sides of a correctly constructed lock and determines cash committed.

![Nested threshold claims exactly reproduce the direct range payoff.](../results/figures/figure_1_payoff_identity.png){#fig:payoff width=92%}

Equation (1) resembles the finite-difference recovery of state prices from option prices [@breeden1978], but no smoothness or option-pricing model is required. Nor is $R_i$'s quoted price assumed to be an unbiased physical probability. Risk premia, inventory, and heterogeneous beliefs may affect both representations. The identification requires only identical terminal cash flows.

## 2.2 Executable synthetic bounds

For any claim $X$, let $B^X_t$ and $A^X_t$ be the recorded bid and ask, and $m^X_t=(B^X_t+A^X_t)/2$. For an interior range, the executable synthetic interval is

$$
B^{S_i}_t=B^{U_i}_t-A^{U_{i+1}}_t,
\qquad
A^{S_i}_t=A^{U_i}_t-B^{U_{i+1}}_t. \tag{3}
$$

For the tails,

$$
[B^{S_0}_t,A^{S_0}_t]
=[1-A^{U_1}_t,1-B^{U_1}_t],
\qquad
[B^{S_J}_t,A^{S_J}_t]=[B^{U_J}_t,A^{U_J}_t]. \tag{4}
$$

The midpoint gap is

$$
g_{i,t}=m^{R_i}_t-m^{S_i}_t. \tag{5}
$$

A positive midpoint gap is not an arbitrage. Before fees, the maximum separation of executable quote intervals is

$$
L_{i,t}=
\max\left\{
B^{S_i}_t-A^{R_i}_t,
B^{R_i}_t-A^{S_i}_t,
0
\right\}. \tag{6}
$$

The first direction buys the direct claim and its synthetic complement, producing a fixed one-dollar terminal payout. The second buys the synthetic range implementation and the direct complement, producing a fixed two-dollar payout. If $F_{i,t}$ is the sum of leg-level fees, cash committed is therefore $1-L_{i,t}+F_{i,t}$ or $2-L_{i,t}+F_{i,t}$, respectively. The paper reports

$$
\text{return on cash}_{i,t}=
\frac{L_{i,t}-F_{i,t}}
{\text{fixed payout}-L_{i,t}+F_{i,t}}. \tag{7}
$$

This is a one-lot accounting sensitivity, not a margin model. It ignores collateral netting, capital opportunity cost, depth, latency, and failure of one leg to fill.

## 2.3 Three additional coherence restrictions

Pairwise replication is not the only model-free restriction. First, the direct range claims form a mutually exclusive and exhaustive partition. For a complete $J+1$ state strip,

$$
\sum_{i=0}^{J}B^{R_i}_t\leq 1
\leq\sum_{i=0}^{J}A^{R_i}_t. \tag{8}
$$

If bids sum above one, selling every state locks more than the one-dollar liability; if asks sum below one, buying every state costs less than its certain one-dollar payout. This is a 30-leg package in the application.

Second, nested thresholds must be non-increasing in strike. An executable two-leg violation occurs when

$$
B^{U_{i+1}}_t>A^{U_i}_t. \tag{9}
$$

Buying the lower strike and selling the higher strike then yields a non-negative terminal payoff with positive initial proceeds. This restriction is cleaner to trade than the three-leg interior range relation, although the historical candle limitation remains.

Third, all direct and threshold intervals should admit one common state-price vector $q=(q_0,\ldots,q_J)$:

$$
q_i\geq0,\quad \sum_iq_i=1,
\quad B^{R_i}_t\leq q_i\leq A^{R_i}_t,
\quad B^{U_j}_t\leq\sum_{i=j}^{J}q_i\leq A^{U_j}_t. \tag{10}
$$

I solve this linear feasibility problem and, when infeasible, minimise a common additive slack $\delta$. Unlike equations (6), (8), and (9), positive $\delta$ is a joint diagnostic; it need not identify a simultaneously executable portfolio from minute-close candles.

# 3. Data, Matching, and Sample Architecture

## 3.1 Market universe and rule verification

The data cover 26 May through 28 July 2026. Each of 43 trading dates contributes one settled S&P 500 event and one settled Nasdaq-100 event, for 86 events in total. Every event contains 30 mutually exclusive range states, giving 2,580 potential direct claims. Structured strike fields, close times, settlement sources, and outcome fields are used to map each range to its threshold legs.

A candidate match is accepted only if:

1. the underlying index and scheduled settlement time are identical;
2. the range boundary exactly equals the relevant threshold strike;
3. the inequality convention reproduces equations (1) and (2), including both tails;
4. the settlement source and event date agree; and
5. the realised range winner is consistent with the recorded threshold outcomes.

The process yields 2,106 exact state matches. Sixty-one events have all 30 states spanned. No approximate strike, title, or time match is retained. This is the core identification decision: machine-readable payoff equivalence substitutes for semantic similarity.

The price data are one-minute historical candles containing closing bid and ask quotes. A static row enters only if the direct claim and every required threshold leg have a closing two-sided quote at the same candle-end timestamp during the final 180 minutes. There is no carry-forward or interpolation.

## 3.2 Nominal observations versus effective coverage

The final panel contains 64,819 synchronous state-minutes covering 1,951 event-state pairs. Those numbers answer different questions. The first is a count of repeated quote configurations; the second is the cross-sectional support. Even 1,951 overstates balanced coverage because quoting is highly concentrated.

| Sample quantity | Value | Interpretation |
|---|---:|---|
| Settled events / trading dates | 86 / 43 | Two index events share each date cluster |
| Exact matched state claims | 2,106 | Rule-verified direct/synthetic pairs |
| Synchronous state-minutes | 64,819 | All required legs quoted at one candle end |
| Event-state pairs represented | 1,951 | Cross-sectional units with at least one row |
| Minutes per event-state, median / p90 / max | 4 / 133 / 181 | Strongly unbalanced quote coverage |
| Row share from top 10% / top 20% of pairs | 48.4% / 78.7% | Near-money books dominate the panel |
| Inverse-Herfindahl coverage | 556 pairs | Concentration diagnostic, not inferential sample size |

: Sample architecture and quote concentration. The inverse-Herfindahl figure is $1/\sum_jw_j^2$ for event-state row shares $w_j$; it is not substituted for the regression sample size.

The median event-state contributes only four quoted minutes. Figure 2 therefore describes the observed synchronous panel, not an equally weighted sample of the full 30-state strip.

![Direct and threshold-implied midpoints in the synchronous panel.](../results/figures/figure_2_price_coherence.png){#fig:coherence width=72%}

The main regressions cluster by trading date. This puts the S&P 500 and Nasdaq-100 events on the same date in one cluster, allowing common macro news and session conditions to correlate their errors. With only 43 clusters, reported hypothesis tests use 4,999-draw Rademacher wild-cluster procedures [@cameron2008].

## 3.3 Endogenous quote availability

A synchronous row exists only when every required book is quoted. Starting from 111,633 minutes with a direct quote, 46,814 (41.9%) lack at least one required threshold quote. Missing-leg rows have a median direct midpoint of 1.5 cents versus 14 cents in the synchronous panel, a median direct spread of two versus three cents, and mean candle volume of 21.3 versus 46.8. The panel therefore selects away from illiquid, deep-out-of-the-money claims.

I also identify a synchronous minute as *adjacent to missing* if the preceding or following minute is unavailable, including a missing direct candle. There are 19,421 such rows. Their mean absolute gap is 1.65 cents and gross candidate rate 1.54%, compared with 1.24 cents and 1.24% in 45,398 non-adjacent synchronous rows. Selection does not reverse the coherence result, but it makes the observed panel mildly optimistic.

## 3.4 Fees and account type

The exchange fee schedule effective 7 July 2026 specifies the general taker fee

$$
F_T(P,C,M)=\operatorname{round\ up}\left[M\times0.07\times C\times P(1-P)\right], \tag{11}
$$

with default multiplier $M=1$ [@kalshi_fees]. Direct exchange-member balances have centi-cent precision; non-direct-member balances have whole-cent precision. The analysis applies the same formula at one contract separately to every leg under each precision regime. It does not infer the account type behind a historical quote.

The schedule also lists the general maker fee as $0.0175\,MCP(1-P)$ and the default maker multiplier as zero for the studied daily products. I therefore add one-, two-, and all-maker-leg sensitivities. These are intentionally conditional. A resting maker order sacrifices atomic execution, may not fill, and may be adversely selected. Zero scheduled maker fee is not zero implementation cost.

The sample straddles 7 July, but the change is not a clean natural experiment: historical account type is absent, product and balance precision are not separately identified in candles, and market conditions change over the same short window. Section 5.4 treats the date as an interrupted-time-series diagnostic, not a causal design.

# 4. Empirical Design

## 4.1 Static coherence, price level, and episodes

Static analysis reports the correlation and distribution of $|g_{i,t}|$, the gross lock condition in equation (6), and fee-adjusted one-lot screens. Results are shown both pooled and event-balanced. Price level is never treated as ancillary: I report fixed price bands and equal-count reference-midpoint deciles, where the reference midpoint is the average of the direct midpoint and the synthetic midpoint clipped to $[0,1]$. Relative gap divides $|g|$ by the reference midpoint floored at one cent.

Repeated positive minutes are collapsed into episodes within an event-state. An episode continues only across consecutive 60-second candle ends and stops at a missing or non-positive minute. The economically cleaner count excludes candles ending exactly at scheduled settlement. For each episode I select its best net quote minute and report profit per one-lot complementary implementation, return on cash from equation (7), and minutes remaining to settlement.

Package and monotonicity restrictions are tested at every complete synchronous 30-state snapshot. The stricter joint programme in equation (10) is evaluated at a common horizon of exactly 180 minutes, leaving 53 complete event surfaces.

## 4.2 Error correction and the shared-lag problem

For exact consecutive minutes, the conventional two-equation model is

$$
\Delta m^R_{i,t}=\alpha_R g_{i,t-1}+x'_{i,t}\gamma_R+\varepsilon^R_{i,t},
\qquad
\Delta m^S_{i,t}=\alpha_S g_{i,t-1}+x'_{i,t}\gamma_S+\varepsilon^S_{i,t}. \tag{12}
$$

Controls $x_{i,t}$ include index, scaled minutes to settlement, the lagged common midpoint, and its square. The primary sample also requires a combined direct-plus-synthetic spread no greater than ten cents. The price controls condition adjustment on the absolute claim level, where tick size is most consequential.

OLS in equation (12) has a mechanical vulnerability. Suppose the latent direct and synthetic prices are equal and observed direct quote error is $u^R_t$. Then

$$
\Delta m^R_t=\Delta p_t+u^R_t-u^R_{t-1},
\qquad
g_{t-1}=u^R_{t-1}-u^S_{t-1}. \tag{13}
$$

Even if $\Delta p_t=0$ and quote errors are independent over time,

$$
\operatorname{Cov}(\Delta m^R_t,g_{t-1})=-\operatorname{Var}(u^R_{t-1}). \tag{14}
$$

With equal direct and synthetic noise variances, the direct OLS coefficient tends to $-1/2$ and the synthetic coefficient to $+1/2$. Bid-ask bounce is the canonical microstructure reason that transaction-price changes can exhibit mechanically negative serial dependence [@roll1984]; here the shared quote produces the problem directly in midpoint algebra.

The formal sensitivity instruments $g_{t-1}$ with both $g_{t-2}$ and $g_{t-3}$. Under serially uncorrelated measurement error,

$$
\operatorname{Cov}(u^R_t-u^R_{t-1},g_{t-k})=0,
\qquad k\in\{2,3\}. \tag{15}
$$

while a persistent structural gap makes the deeper lags relevant for $g_{t-1}$. This creates a useful diagnostic symmetry: under a pure white-noise gap both instruments should be weak; a strong joint first stage indicates persistence beyond that null. The second excluded lag overidentifies the single endogenous regressor, permitting an equation-specific cluster-robust Hansen $J$ test of whether the two moments are mutually consistent. Non-rejection does not prove that both are valid: stale quotes or serially correlated measurement error could contaminate them together. IV is therefore presented as a measurement-error-robust design conditional on equation (15), not as a causal natural experiment.

Requiring four consecutive observations leaves 25,529 observations and 43 date clusters. The ends of short quote runs are therefore absent from IV. To separate that sample-composition change from the estimator change, I re-estimate OLS on exactly the same 25,529 rows, with identical outcomes and controls. I report the joint date-clustered first-stage Wald $F$, conventional date-clustered $t$ intervals, and wild-cluster $p$-values. For IV coefficients, the wild statistic is an Anderson-Rubin-style joint reduced-form test on both excluded instruments. A 999-replication null simulation uses this same common sample, holds the latent price constant, and draws independent direct and synthetic quote errors at current, lagged, second-lag, and third-lag times.

If $0<1+\alpha_R-\alpha_S<1$, the gap half-life is

$$
h=\frac{\log(1/2)}{\log(1+\alpha_R-\alpha_S)}. \tag{16}
$$

The Gonzalo-Granger-style direct component share is $\alpha_S/(\alpha_S-\alpha_R)$ [@gonzalo1995]. Because it is a ratio of two jointly estimated adjustment coefficients, a delta-method interval can be unreliable when the denominator is uncertain. I therefore report both a 10,000-draw whole-date percentile bootstrap and the Fieller confidence set for the ratio [@fieller1954]. The unconstrained estimator can leave $[0,1]$ when a draw violates the equilibrium-correction sign pattern; I show that result rather than clipping it, and separately intersect the Fieller set with the economically admissible share space. The point estimate is not treated as a causal share of informed trading. Each bootstrap draw re-estimates both IV equations and recomputes persistence, half-life, and the component share jointly. Because $\alpha_S$ is imprecise, I also report the transparent sensitivity that sets $\alpha_S=0$ and derives half-life from the direct response alone.

## 4.3 Mapping placebo

The contract map could appear successful simply because neighbouring state surfaces are smooth. I therefore replace each synthetic state with the state two bins higher within the same event and minute. The shift is non-adjacent, preserves the same market, session, and broad probability surface, and is known to be payoff-incorrect. I recompute contemporaneous alignment and the price-controlled OLS error-correction model. The exercise asks whether exact payoff identity, rather than generic co-movement, drives the result.

At the complete-surface horizon I use two further controls: a one-bin adjacent-state mapping and 1,000 random within-surface permutations. Errors are reported for all states and for *active* states, where either exact representation has a midpoint of at least five cents.

## 4.4 Forecasting and calibration

The individual-claim forecast panel chooses the closest observation within 15 minutes after each target horizon of 120, 60, 30, and 10 minutes. A pair remains only if it exists at all four horizons and its event's realised state is present at all four. This yields 278 event-state pairs across 59 events: a mean of 4.71 states per event, median four, and maximum 21. At 120 minutes the direct midpoint interquartile range is 5.0% to 27.9%, and 21.2% of retained rows are winners. This is a liquid, near-money subset, not the full 30-state partition.

I compare the direct midpoint, the clipped synthetic midpoint, and an inverse-spread-squared fusion. Brier and logarithmic scores are strictly proper [@brier1950; @gneiting2007]. Absolute error is retained as a descriptive loss but not used for the central probability-forecast claim. Differences are averaged within event and bootstrapped by event.

Separately, every complete 30-state direct and synthetic surface at 180 minutes is projected onto the unit simplex. A joint fused distribution fits both primitive range quotes and cumulative threshold quotes with inverse-spread weights. The methods are evaluated by multicategory Brier, logarithmic, and ranked probability scores. A reliability curve bins raw direct and clipped synthetic midpoints; event-resampling intervals preserve within-event outcome dependence.

# 5. Results

## 5.1 Prices are coherent; executable evidence is scarce

Direct and threshold-implied midpoints have correlation 0.9913. The median absolute gap is one cent, the 90th percentile is 2.5 cents, and the median relative gap is 6.45% after flooring the denominator at one cent. The last statistic shows why absolute and relative interpretations diverge in the tail.

Price conditioning reveals a non-monotonic candidate profile. The lowest decile, whose midpoint is at most 0.5 cents, has no gross quote separation. Gross rates then peak at 3.69% in the third decile, with median reference price 3.25 cents, and rise again to 2.53% in the highest decile. In the full panel, 40.3% of gross candidates have reference price at or below five cents. After direct-member all-taker fees, that full-panel share rises to 74.5%. Yet none of the full-panel non-direct whole-cent positives is below five cents. These composition shares deliberately retain the scheduled-close candle; Table 2 removes it before constructing episodes.

The apparent inversion has one mechanism. Whole-cent balance precision rounds each positive one-lot taker fee separately, imposing a roughly three-cent minimum fee bill on a three-leg interior package. The loose gross screen therefore detects one- and two-tick disagreements disproportionately in low-price claims, while the strictest screen requires a much larger *absolute* separation regardless of relative value. Those separations occur in wider high-price books: the 50-100 cent band has the highest fixed-band gross rate, 2.707%, and contains seven of the 13 full-sample non-direct positives; those seven state-minutes have a 33-cent median combined spread. Fee granularity thus changes the selected population rather than revealing a reversal in relative mispricing.

![Quoted-lock rates by price decile and fixed-horizon calibration.](../results/figures/figure_10_price_and_calibration.png){#fig:pricecal width=96%}

The full panel contains 862 gross positive state-minutes (1.330%). Excluding the scheduled-close candle leaves 849 minutes in 607 contiguous episodes across 240 event-state pairs and 69 events. Table 2 applies account-type and maker assumptions to the same pre-close observations.

| Fee and execution screen | Positive minutes | Episodes | Event-state pairs | Events | Median best profit | Median return on cash | Median holding time |
|---|---:|---:|---:|---:|---:|---:|---:|
| Before fees | 849 | 607 | 240 | 69 | 1.00c | 0.503% | 85 min |
| Direct member, all legs taker | 431 | 280 | 141 | 55 | 0.51c | 0.256% | 89 min |
| Direct member, one maker leg | 599 | 405 | 188 | 63 | 0.72c | 0.361% | 85 min |
| Direct member, two maker legs | 805 | 567 | 233 | 68 | 0.93c | 0.467% | 85 min |
| Non-direct member, all legs taker | 6 | 5 | 5 | 3 | 2.00c | 2.041% | 82 min |

: Positive quote configurations before scheduled settlement. Profit and return are calculated at the best minute in each episode for a one-lot complementary-claim implementation. They condition on every recorded closing quote being simultaneously executable in full, which the data cannot establish.

The non-direct result is easy to misread. Five episodes are extremely rare, but their conditional return on cash is not economically negligible: the median is 2.04% for about 82 minutes to settlement. That is precisely why the execution limitation matters. A one-minute candle provides neither historical depth nor evidence that three legs could be completed before quotes moved. Moreover, taking the best quote in every episode and granting perfect one-lot execution produces only ten cents of aggregate hypothetical profit over the full two-month, 43-date sample. A high conditional percentage on a sparse, capacity-limited opportunity set cannot be sensibly annualised. The necessary execution data are absent, and even the deliberately favourable one-lot upper bound is economically negligible.

Maker sensitivities move the screen sharply because the published default maker multiplier is zero. One maker leg raises the pre-close count from 280 to 405 episodes; two maker legs raise it to 567. But a basket containing resting orders is not atomic. The sensitivity identifies where a live execution engine would focus; it does not convert the historical sample into a backtest.

\Needspace{4.1in}

![Candidate rates depend strongly on fees, account precision, and maker assumptions.](../results/figures/figure_4_quoted_locks.png){#fig:locks width=78%}

## 5.2 IV separates persistent repair from shared-lag noise

The OLS benchmark appears symmetric. Conditional on price level, index, horizon, and a combined spread no greater than ten cents, the direct midpoint responds by -0.333 and the synthetic midpoint by +0.358 to a one-dollar lagged gap. Both wild-cluster $p$-values are below 0.001. Taken literally, the coefficients imply that 69.1% of a gap disappears in one minute and that the direct representation supplies 51.9% of the common component.

That literal interpretation fails the noise audit. In the pure independent-noise simulation, the median direct OLS coefficient is -0.500 and the median synthetic coefficient +0.500, with narrow 95% simulation ranges of approximately [-0.510,-0.490] and [0.490,0.510]. The construction alone can therefore generate an apparently fast, two-sided correction.

Both excluded lags are relevant for the observed gap. Conditional first-stage coefficients are 0.364 (SE 0.023) on $g_{t-2}$ and 0.225 (SE 0.018) on $g_{t-3}$. Their joint date-clustered Wald F is 276.8 and the wild-cluster $p$-value is 0.0002. Under the 999 pure-noise simulations, median joint F is 0.74, the 95th percentile is 3.41, and no draw reaches the observed statistic. This rejects the specific white-noise explanation for gap persistence.

The additional instrument does not expose a conflict between the two exclusion moments. The cluster-robust Hansen diagnostics are $J(1)=0.684$ ($p=0.408$) in the direct equation and $J(1)=0.035$ ($p=0.851$) in the synthetic equation. These are non-rejections, not certificates of validity: common serial quote staleness could still contaminate both lags, and a one-degree-of-freedom test in 43 dates has limited power.

\Needspace{5.4in}

| Estimator | Next-minute outcome | Gap response | Date-clustered SE | 95% interval | Wild-cluster $p$ |
|---|---|---:|---:|---:|---:|
| OLS, full primary sample | Direct range change | -0.333 | 0.043 | [-0.420, -0.246] | 0.0002 |
| OLS, full primary sample | Threshold-implied change | +0.358 | 0.052 | [+0.254, +0.463] | 0.0002 |
| OLS, IV common sample | Direct range change | -0.277 | 0.038 | [-0.353, -0.201] | 0.0002 |
| OLS, IV common sample | Threshold-implied change | +0.319 | 0.042 | [+0.234, +0.403] | 0.0002 |
| IV: $g_{t-2},g_{t-3}$ instruments | Direct range change | -0.151 | 0.040 | [-0.232, -0.069] | 0.0002 |
| IV: $g_{t-2},g_{t-3}$ instruments | Threshold-implied change | +0.045 | 0.035 | [-0.025, +0.115] | 0.4360 |

: Error correction in the primary spread-filtered sample. Full-sample OLS uses $N=32,921$; common-sample OLS and overidentified IV use the identical $N=25,529$ rows. All specifications use 43 date clusters and the same price-level controls. For IV, the wild-cluster entry is an Anderson-Rubin-style joint reduced-form test of both excluded lags.

![OLS and overidentified IV estimates of next-minute gap repair.](../results/figures/figure_5_error_correction.png){#fig:ecm width=94%}

The common-sample comparison rules out a purely compositional explanation, but not a partial one. Total one-minute OLS repair falls from 69.1% in the 32,921-row primary sample to 59.6% on the 25,529 IV rows, then to 19.6% under IV. At the point estimates, loss of short quote runs accounts for 9.5 percentage points, about one fifth of the full 49.5-point attenuation; changing the estimator on a fixed sample accounts for 40.0 points, about four fifths. The direct coefficient follows the same decomposition, -0.333 to -0.277 to -0.151, while the synthetic coefficient moves from +0.358 to +0.319 to +0.045. Identification is the dominant change, but sample continuity is not innocuous.

IV changes the economic conclusion. The direct book moves reliably toward a persistent threshold-implied signal; the estimated synthetic response is positive but imprecise. Jointly, the coefficients imply persistence of 0.804 and a half-life of 3.18 minutes. A 10,000-draw date-cluster bootstrap gives [2.35,4.36] minutes, so the result is slower than OLS without resting on false decimal precision. Because $\alpha_S$ is not distinguishable from zero, a restricted sensitivity sets it to zero: persistence becomes 0.849 and half-life 4.25 minutes, with a wider [2.53,8.50] bootstrap interval.

Direction should not be discarded merely because it is uncertain. The direct component-share point estimate is 23.0%, equivalent to a 77.0% threshold-representation weight in the common component. The whole-date percentile-bootstrap interval is [-11.4%,56.7%], and the Fieller interval is [-13.4%,60.0%]; no delta-method interval is used. About 90.3% of bootstrap draws satisfy the economically admissible $[0,1]$ share restriction, while 9.7% imply the wrong sign for $\alpha_S$. Intersecting the Fieller set with the admissible parameter space gives [0.0%,60.0%]. The point estimate and the one-sided adjustment pattern therefore suggest that threshold books may lead and the direct range book follows, but every interval includes one half and cannot exclude parity.

The two-state dynamic placebo makes the identification visible. On its common overlap, the exact map has correlation 0.985 and mean absolute gap 1.26 cents. The wrong-state map has correlation -0.058 and mean absolute gap 14.44 cents. In 16,782 price-controlled dynamic observations, its OLS coefficients are only -0.0045 and +0.0056: together they repair 1.01% of the wrong-state gap per minute, versus 69.1% for exact-map OLS. Exact contract logic, not generic state-surface smoothness, drives the measured relationship.

## 5.3 The strip passes simple arbitrage tests but exposes joint tension

The direct-package and threshold-monotonicity results are unambiguous. There are 68 timestamps, covering 53 events and 33 dates, at which all 30 states and 29 thresholds are synchronously observed. None violates equation (8), and none contains the two-leg violation in equation (9). The maximum sum of direct bids is exactly one, so at least one snapshot sits precisely on the gross package boundary rather than comfortably inside it; it does not cross the boundary, and leg-level fees make equality negative after costs. The minimum sum of direct asks is 1.38. Eleven snapshots contain at least one pairwise gross range-versus-synthetic candidate, but no additional direct-strip or monotonicity arbitrage appears.

The stricter common-distribution test detects a different object. At exactly 180 minutes, 34 of 53 complete surfaces admit a $q$ satisfying every direct and threshold interval. Nineteen are jointly infeasible. Their minimum common relaxation never exceeds one cent; the 75th percentile across all surfaces is one-third of a cent. Eleven infeasible surfaces have no pairwise gross candidate. Shared threshold legs can therefore create a small global inconsistency even when every local relation passes separately.

| Coherence layer | Sample | Result | Interpretation |
|---|---:|---:|---|
| Direct partition package | 68 complete snapshots | 0 violations | No 30-leg bid/ask package separation |
| Threshold monotonicity | 68 complete snapshots | 0 violations | No higher-strike bid above lower-strike ask |
| Pairwise range replication | 68 complete snapshots | 11 positive snapshots | Local gross quote separation before fees |
| Joint price-system LP | 53 surfaces at 180 min | 34 feasible; 19 infeasible | One distribution does not fit every interval |
| Joint LP failures unseen pairwise | 53 surfaces at 180 min | 11 surfaces | Global constraints add information |
| Maximum uniform LP relaxation | 53 surfaces at 180 min | 1.00c | Joint tensions are small |

: Nested model-free coherence tests. A positive joint LP slack is a market-quality diagnostic, not proof of an atomically executable multi-leg trade.

The complete-surface falsification reinforces the map. Among active states, mean absolute error is 1.68 cents under the exact rule mapping, 11.97 cents after an adjacent-state shift, and 17.21 cents under within-surface permutation. Thus, even though the surface is smooth and many states are near zero, the correct payoff map is far more precise than plausible wrong-state alternatives.

![Complete-surface mass, joint feasibility, and mapping falsification.](../results/figures/figure_9_whole_surface_audit.png){#fig:surfaceaudit width=98%}

## 5.4 Selection and the fee-date diagnostic do not rescue a trading claim

The adjacent-missing sensitivity suggests that quote availability is informative. Gaps are somewhat larger and gross candidates somewhat more frequent next to unavailable minutes. The effect is not large enough to overturn the central static result, but it confirms that the 64,819-row panel is a selected liquid subset. Any claim about the full 30-state universe would require a model of quote arrival or message-level books, neither of which is available here.

The 7 July schedule date produces a visually tempting break: event-balanced gross candidate rates average 1.656% before and 0.520% on or after the date, while mean combined spread rises from 9.40 to 12.26 cents. An interrupted-time-series regression with index, linear pre/post trends, median price, and quote-count controls estimates a -1.92 percentage-point level shift in the gross rate, but the wild-cluster $p$-value is 0.0936. The corresponding spread-shift $p$-value is 0.0718; median-gap $p=0.7048$. In a 43-date sample with unidentified account type and changing liquidity, these results are suggestive at most. The paper rejects the proposed causal “natural experiment” framing.

## 5.5 Reconciliation does not improve proper scores robustly

Brier scores improve as settlement approaches, as expected. At 120 minutes the event-balanced direct, synthetic, and fused scores are 0.1668, 0.1675, and 0.1672. At 10 minutes they are 0.1195, 0.1216, and 0.1201. Every paired-event 95% interval for synthetic-minus-direct and fused-minus-direct Brier score includes zero. The same is true for log score. Synthetic probabilities have lower absolute error at 10 minutes, but absolute loss does not elicit the full probability and is not the paper's proper-score criterion.

| Horizon | Direct Brier | Synthetic Brier | Fused Brier | Synthetic - direct, 95% CI | Fused - direct, 95% CI |
|---:|---:|---:|---:|---:|---:|
| 120 min | 0.1668 | 0.1675 | 0.1672 | [-0.0024, 0.0035] | [-0.0005, 0.0013] |
| 60 min | 0.1580 | 0.1603 | 0.1583 | [-0.0014, 0.0055] | [-0.0023, 0.0021] |
| 30 min | 0.1348 | 0.1366 | 0.1360 | [-0.0007, 0.0051] | [-0.0001, 0.0034] |
| 10 min | 0.1195 | 0.1216 | 0.1201 | [-0.0027, 0.0073] | [-0.0024, 0.0038] |

: Paired individual-claim Brier scores. Lower is better. Intervals resample whole events and apply to the score difference.

The complete-surface exercise reaches the same conclusion. Direct, synthetic, and fused multicategory Brier scores are 0.7789, 0.7855, and 0.7816. The fused-minus-direct interval is [-0.0014,0.0071]. Ranked probability score is slightly lower for fusion by 0.00059, but its interval [-0.00169,0.00035] includes zero. Reconciliation enforces coherence; it does not reliably add forecast information.

Calibration is reasonably close at the coarse resolution supported by 53 events. Expected calibration error is 1.58 percentage points for direct midpoints and 1.21 for synthetic midpoints. The largest direct bin, 942 observations with mean quoted probability 0.80%, contains no realised winners; the next bin, from 1% to 2.5%, has mean 1.71% and realised frequency 0.83%. At the other tail, the 40%-100% direct bin has mean quote 48.8% and realised frequency 69.2%; the synthetic figures are 47.8% and 69.2%. For direct quotes, overpriced longshots together with underpriced higher-probability states form the textbook two-tail direction of favourite-longshot bias [@buergi2026]. The threshold-implied series is not uniformly longshot-overpriced in its smallest bins, so the evidence is directional rather than universal. Tick floors, midpoint construction, spreads, and quote selection remain competing mechanisms. Most importantly, the high bin contains only 13 observations: the joint pattern is consistent with favourite-longshot bias, but this sample cannot establish its favourite-side leg or identify its cause.

![Proper-score performance through settlement.](../results/figures/figure_6_forecast_scores.png){#fig:forecast width=78%}

# 6. Interpretation and Limitations

## 6.1 What a trader can take from the design

The practical insight is a workflow, not a claimed strategy. Begin with an exact payoff graph; derive executable synthetic quotes using the correct book sides; evaluate all directions after leg-level fees; control for price level and account type; then require live depth and atomic fill logic before treating a historical inequality as P&L. Redundant contracts are valuable because each book provides a model-free reference for the other.

A live implementation would maintain the constraint system in equations (3), (8), (9), and (10) after every message. It would rank candidates by net return on cash and executable size, not by midpoint gap; reserve inventory for unmatched-leg risk; model queue position for maker orders; and cancel the basket when any leg moves. The present data do not contain the fields needed to simulate those decisions. The maker analysis shows why such an engine could be interesting, while simultaneously showing why candles cannot validate it.

The IV result also matters operationally. OLS says both books snap together in under a minute, but much of that symmetry is a shared-lag noise artefact. The overidentified estimate instead places the unrestricted half-life between 2.35 and 4.36 minutes, while the $\alpha_S=0$ sensitivity reaches 8.50 minutes at its upper endpoint. A trader calibrating execution horizons from the naive half-life would be systematically overconfident.

## 6.2 What the paper does not establish

**Atomic execution.** One-minute candles report closing top-of-book quotes, not a simultaneous message-level snapshot. Different legs can have different last quote times within the same minute.

**Capacity.** Historical depth, order size, queue position, partial fills, cancellations, and adverse selection are unavailable. Every candidate count is one-lot and conditional on displayed closing quotes.

**A causal fee effect.** The 7 July date coincides with unidentified account types and evolving market conditions. The break analysis is descriptive.

**An unconditional market-wide panel.** Requiring every leg to be quoted selects liquid and higher-price states. Adjacent-missing rows show somewhat worse coherence, and states with no direct candle cannot be evaluated.

**An assumption-free IV.** The lag-two and lag-three exclusions require quote measurement error to be serially uncorrelated after controls. Staleness could violate both conditions together. The strong joint first stage rejects the pure white-noise relevance null, and Hansen tests find no disagreement between instruments; neither result proves exclusion.

**Stable structural parameters.** The sample spans 43 dates, two related index underlyings, and a short period. Date clustering, wild inference, and placebo tests improve honesty but do not create long-horizon external validity.

**Physical probabilities.** Midpoints may embed risk premia, inventory costs, discreteness, and fees. The direct-quote calibration pattern is consistent with favourite-longshot bias, but the high bin has only 13 observations and the design does not identify the mechanism.

**Unrestricted redistribution.** The collector and paper rely on exchange API data. The public-release decision must follow the then-current developer agreement and written-authorisation requirements [@kalshi_agreement].

# 7. Conclusion

One event outcome can trade twice on the same exchange: directly as a range and indirectly through nested thresholds. That redundancy creates a rare market-microstructure experiment in which the benchmark price relation follows from the contract rules rather than a model of value.

The evidence is strong on coherence and weak on exploitable arbitrage. Prices correlate at 0.9913 and differ by a median one cent. Gross interval separations occur, but they collapse sharply when minutes are grouped into episodes, fees and account precision are applied, and the scheduled-close candle is excluded. Five non-direct pre-close episodes survive the strictest screen; candles cannot establish simultaneous execution, and even perfect one-lot fills at every episode's best quote sum to only ten cents over the sample. The paper therefore makes no realised-profit or scalable-strategy claim.

The most important revision concerns price discovery. The conventional error-correction regression is mechanically biased because lagged quote error enters both sides with opposite signs. A pure-noise simulation reproduces apparent two-sided repair. Common-sample OLS shows that dropping the ends of short quote runs explains about one fifth of the point-estimate reduction in total adjustment; the fixed-sample estimator change explains about four fifths. Overidentified lag-two/lag-three IV has a strong joint first stage, passes equation-specific Hansen diagnostics, and estimates a 3.18-minute half-life with a [2.35,4.36] date-cluster bootstrap interval. The direct response is reliable and the synthetic response imprecise; setting the latter to zero gives a 4.25-minute sensitivity. The 23.0% direct-component point estimate suggests threshold books may lead, though both bootstrap and Fieller intervals retain parity. A wrong-state placebo collapses both alignment and adjustment, showing that the exact payoff map—not generic co-movement—identifies the system.

The broader coherence audit adds two disciplined negative results. Complete strips contain no executable partition or threshold-monotonicity violation, while a joint LP finds only small, non-atomic surface tensions. Reconciliation enforces valid probability distributions but does not improve proper forecast scores robustly. Redundancy is therefore most useful as a control system: it reveals quote noise, constrains surfaces, falsifies mappings, and prevents a seductive but unsupported trading narrative.

# Appendix A. Pointwise Proofs and Portfolio Cash Flows

For an interior state, consider the three regions $S_T<K_i$, $K_i\leq S_T<K_{i+1}$, and $S_T\geq K_{i+1}$. The pair $(U_i,U_{i+1})$ equals $(0,0)$, $(1,0)$, and $(1,1)$ respectively. Therefore $U_i-U_{i+1}$ equals $0,1,0$, exactly the range payoff.

For the left tail, $1-U_1$ equals one precisely when $S_T<K_1$. For the right tail, the direct event $S_T\geq K_J$ is the threshold event itself.

The two directional interior portfolios can be implemented using purchases of complementary binary claims:

| Direction | Purchased legs | Fixed terminal payout | Cash cost before fees |
|---|---|---:|---:|
| Direct cheap | Range YES; lower-threshold NO; higher-threshold YES | $1$ | $1-(B^{S_i}-A^{R_i})$ |
| Synthetic cheap | Lower-threshold YES; higher-threshold NO; range NO | $2$ | $2-(B^{R_i}-A^{S_i})$ |

: Complementary-claim implementations for the two interior-state lock directions. Each portfolio has a fixed terminal payout and requires three purchased legs.

The identities explain why equation (7) uses a one- or two-dollar denominator. They also avoid assuming that historical short sales received unconstrained cash proceeds.

# Appendix B. Matching and Validation Protocol

The processed contract map stores event identifier, underlying, close time, range-state index, state type, lower and upper numeric boundaries, direct ticker, required threshold tickers, and realised outcome. States are sorted from the left tail through interior intervals to the right tail.

The validation suite checks:

1. ordered, non-overlapping, exhaustive state boundaries within each event;
2. exact equality between every range boundary and mapped threshold strike;
3. identical close timestamps and underlying index labels;
4. exactly one winning range state per settled event;
5. threshold outcomes that are weakly decreasing in strike;
6. pointwise payoff identities for interior and tail claims;
7. valid direct and synthetic quote intervals;
8. correct directional lock detection and leg-side selection;
9. direct-member, non-direct-member, and maker fee rounding;
10. coherent simplex projection and spread-weighted fusion; and
11. linear-programme recovery of feasible and minimally relaxed price systems.

The final code release contains 12 unit tests because the maker-fee multiplier is tested separately from the two taker-precision regimes.

# Appendix C. Additional Diagnostics

## C.1 Price bands

| Reference-price band | Observations | Gross candidates | Gross rate | Direct-member positives | Non-direct positives | Median relative gap |
|---|---:|---:|---:|---:|---:|---:|
| 0-2.5c | 14,705 | 217 | 1.476% | 216 | 0 | 100.0% |
| 2.5-5c | 5,011 | 130 | 2.594% | 114 | 0 | 28.6% |
| 5-10c | 7,583 | 112 | 1.477% | 46 | 2 | 13.3% |
| 10-25c | 16,724 | 134 | 0.801% | 28 | 4 | 4.65% |
| 25-50c | 14,960 | 111 | 0.742% | 9 | 0 | 2.50% |
| 50-100c | 5,836 | 158 | 2.707% | 30 | 7 | 1.83% |

: Candidate composition by fixed price band. All counts and the 40.3% and 74.5% composition shares in Section 5.1 use the full synchronous panel, including the scheduled-close candle. Direct-member and non-direct positives therefore sum to 443 and 13 here; Table 2 first removes that candle and reports 431 and 6 pre-close positive minutes before collapsing them into episodes.

## C.2 OLS robustness

The one-cent median gap is unchanged when restricting to interior states, excluding the final ten minutes, sampling at five-minute timestamps, or separating the two indices. Gross candidate rates range from 1.10% for Nasdaq-100 to 1.67% for S&P 500. Under the combined-spread-at-most-ten-cents filter, the gross rate is 1.75%, reflecting selection toward tighter and more actively quoted books rather than a broader population.

Five-minute ECM estimates and index-specific estimates preserve the sign pattern of the OLS benchmark. They do not solve the shared-lag problem; for that reason they remain robustness descriptions rather than headline identification.

## C.3 Case study

The most persistent direct-member-positive event-state is Nasdaq-100 event `KXNASDAQ100-26JUN24H1600`, state 10, on 24 June 2026. It has 148 synchronous observations, 42 direct-member-positive minutes, a maximum absolute midpoint gap of 2.5 cents, and maximum direct-member net separation of 0.65 cents. Repetition does not create 42 independent trades: it is one state with a persistent quote configuration. This case motivated the episode count and illustrates why minute-level candidate totals must not be read as capacity.

![A persistent quote configuration can create many minute observations without many independent opportunities.](../results/figures/figure_7_case_study.png){#fig:case width=88%}

## C.4 Complete-surface forecast scores

| Method | Multicategory Brier | Log score | Ranked probability score |
|---|---:|---:|---:|
| Direct simplex projection | 0.7789 | 1.9182 | 0.03743 |
| Synthetic simplex projection | 0.7855 | 2.0129 | 0.03861 |
| Joint spread-weighted fusion | 0.7816 | 1.9681 | 0.03684 |

: Complete-surface forecast scores at 180 minutes. Lower values are better.

Paired-event bootstrap intervals include zero for every synthetic-minus-direct and fused-minus-direct score difference. Projection should therefore be understood as coherence enforcement, not a forecast-performance guarantee [@predd2009; @zhang2024].

# Appendix D. Reproducibility and Research Integrity

The project is organised into four layers:

| Layer | Purpose | Main output |
|---|---|---|
| Collection | Retrieve event, market, and one-minute candle data | Normalised private raw tables |
| Contract map | Parse rules and verify exact payoff identities | `contract_map.csv` and validation fields |
| Analysis | Build synchronous panel; estimate screens, IV, placebos, LPs, and scores | Aggregate tables, figures, manifest |
| Publication | Render the paper and package non-row-level outputs | PDF, DOCX, checksums, archive |

: Reproducibility layers and principal outputs.

The analysis fixes one random seed. Wild-cluster tests use 4,999 draws; the IV noise null uses 999 replications; IV date-cluster and event-level forecast bootstraps use 10,000 resamples; and whole-surface permutation controls use 1,000 draws per event. Machine-readable headline results are written to `results/results_manifest.json`. Aggregate tables retain more precision than the paper, preventing rounded display values from becoming analysis inputs.

Raw data and row-level derived quote observations are excluded from the distributable archive. Reproduction requires retrieving data under the exchange's then-current terms, running the collector, analysis, and test suite, rebuilding both document formats, and visually inspecting every rendered page.

\newpage
