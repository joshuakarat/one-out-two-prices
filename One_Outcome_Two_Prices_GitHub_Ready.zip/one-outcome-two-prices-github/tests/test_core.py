from __future__ import annotations

import sys
import unittest
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from o2p.core import (  # noqa: E402
    Quote,
    consistent_price_system,
    direct_member_fee,
    fused_distribution,
    maker_fee,
    project_simplex,
    quoted_lock,
    non_direct_member_fee,
    synthetic_quote,
)


class PayoffIdentityTests(unittest.TestCase):
    def test_interior_payoff_identity(self) -> None:
        for terminal in np.arange(0, 21):
            direct = int(5 <= terminal < 10)
            thresholds = int(terminal >= 5) - int(terminal >= 10)
            self.assertEqual(direct, thresholds)

    def test_tail_payoff_identities(self) -> None:
        for terminal in np.arange(0, 21):
            self.assertEqual(int(terminal < 5), 1 - int(terminal >= 5))
            self.assertEqual(int(terminal >= 10), int(terminal >= 10))


class QuoteAlgebraTests(unittest.TestCase):
    def test_interior_synthetic_bounds(self) -> None:
        synthetic = synthetic_quote(
            "interior", Quote(0.60, 0.62), Quote(0.35, 0.38)
        )
        self.assertAlmostEqual(synthetic.bid, 0.22)
        self.assertAlmostEqual(synthetic.ask, 0.27)

    def test_tail_synthetic_bounds(self) -> None:
        left = synthetic_quote("left_tail", None, Quote(0.35, 0.38))
        self.assertAlmostEqual(left.bid, 0.62)
        self.assertAlmostEqual(left.ask, 0.65)
        right = synthetic_quote("right_tail", Quote(0.60, 0.62), None)
        self.assertEqual(right, Quote(0.60, 0.62))

    def test_quoted_lock_detection(self) -> None:
        gross, direction = quoted_lock(Quote(0.20, 0.22), Quote(0.25, 0.28))
        self.assertAlmostEqual(gross, 0.03)
        self.assertEqual(direction, "buy_direct_sell_synthetic")


class FeeTests(unittest.TestCase):
    def test_centicent_fee(self) -> None:
        self.assertEqual(direct_member_fee(0.50), 0.0175)
        self.assertEqual(direct_member_fee(0.01), 0.0007)

    def test_non_direct_member_fee(self) -> None:
        self.assertEqual(non_direct_member_fee(0.50), 0.02)
        self.assertEqual(non_direct_member_fee(0.01), 0.01)
        self.assertEqual(non_direct_member_fee(0.00), 0.00)

    def test_maker_fee_multiplier(self) -> None:
        self.assertEqual(maker_fee(0.50), 0.0)
        self.assertEqual(maker_fee(0.50, multiplier=1.0), 0.0044)


class ReconciliationTests(unittest.TestCase):
    def test_simplex_projection(self) -> None:
        projected = project_simplex(np.array([0.8, 0.4, -0.1]))
        self.assertTrue(np.all(projected >= 0))
        self.assertAlmostEqual(float(projected.sum()), 1.0)

    def test_fusion_is_coherent(self) -> None:
        direct = np.array([0.2, 0.5, 0.4])
        thresholds = np.array([0.75, 0.30])
        fused = fused_distribution(
            direct,
            thresholds,
            np.array([0.04, 0.03, 0.05]),
            np.array([0.03, 0.04]),
        )
        self.assertTrue(np.all(fused >= -1e-10))
        self.assertAlmostEqual(float(fused.sum()), 1.0, places=8)

    def test_joint_surface_is_feasible(self) -> None:
        result = consistent_price_system(
            np.array([0.30, 0.60]),
            np.array([0.40, 0.70]),
            np.array([0.60]),
            np.array([0.70]),
        )
        self.assertTrue(result.feasible)
        self.assertAlmostEqual(result.minimum_uniform_slack, 0.0)
        self.assertAlmostEqual(float(result.coherent_distribution.sum()), 1.0)

    def test_joint_surface_reports_minimum_slack(self) -> None:
        result = consistent_price_system(
            np.array([0.60, 0.30]),
            np.array([0.70, 0.40]),
            np.array([0.60]),
            np.array([0.70]),
        )
        self.assertFalse(result.feasible)
        self.assertAlmostEqual(result.minimum_uniform_slack, 0.10, places=8)


if __name__ == "__main__":
    unittest.main()
